<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Andes Game Studio C.A. – Desarrollamos cautivadores juegos Match-3 para iOS y Android. Descubre nuestra pasión por la innovación y la diversión en cada nivel.">
  <meta name="keywords" content="Andes Game Studio, juegos Match-3, desarrollo de videojuegos, iOS, Android, juegos móviles, Caracas, Venezuela, estudio de juegos, entretenimiento digital">
  <title>Andes Game Studio C.A. | Desarrolladores de Juegos Match-3</title>
  <!-- Bootstrap 5 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts (Poppins) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="frontend/style.css">
  <link rel="icon" type="image/svg+xml" href="frontend/pictures/andes-game-studio-favicon.svg">
</head>

<body class="bg-light-blue">

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="me-2" style="height: 40px;">
        <span class="fw-bold text-steel-blue">Andes Game Studio</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#hero">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#about">Nosotros</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#services">Servicios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#games">Juegos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#team">Equipo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#contact-form">Contacto</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- Hero Section -->
    <section id="hero" class="hero-section d-flex align-items-center justify-content-center text-white text-center py-5 position-relative">
      <div class="hero-overlay"></div>
      <img src="frontend/pictures/pics/match3-hero-background.png" alt="Andes Game Studio Background" class="hero-bg-image position-absolute w-100 h-100 object-fit-cover">
      <div class="container position-relative z-1">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-8">
            <h1 class="display-3 fw-bold mb-3">Andes Game Studio: Donde la Magia de los Match-3 Cobra Vida</h1>
            <p class="lead mb-4">Creamos experiencias de juego Match-3 cautivadoras para iOS y Android, fusionando creatividad y tecnología para entretener a millones.</p>
            <a href="./"
              class="btn btn-lg btn-primary-custom shadow-lg"
              onclick="sessionStorage.setItem('openContactModal', 'true')">
              ¡Hablemos de tu Próximo Juego!
            </a>
          </div>
        </div>
      </div>
    </section>

    <div style="padding-top: 50px; padding-bottom: 50px;">

      <div class="rightsCloudWrap">
        <div id="policy-container" class="policy-container">
          <div id="introduction" class="policy-section-wrap">
            <h2 class="section-container-title">Introducción</h2>
            <p class="section-container-paragraph">
              Bienvenido a Andes Game Studio C.A.. El presente documento constituye un acuerdo legal entre usted, usuario de los servicios ofrecidos a través de este sitio web, y Andes Game Studio C.A., en adelante "la Compañía". Al acceder y hacer uso de nuestro sitio web, usted acepta las condiciones aquí establecidas en su totalidad, por lo que le recomendamos leer detenidamente cada sección de esta exención de responsabilidad. Este documento tiene como finalidad informar de manera transparente sobre la manera en que se gestionan y protegen sus datos personales, así como detallar las limitaciones y alcances de la responsabilidad de la Compañía en relación con la prestación de servicios.
            </p>
            <p class="section-block-paragraph">
              En este documento se explican aspectos fundamentales relacionados con la privacidad, el uso de cookies y la seguridad de la información, en conformidad con las normativas locales y las recomendaciones en materia de publicidad digital. El presente texto está redactado de conformidad con las leyes vigentes en la jurisdicción aplicable, y tiene carácter informativo para el usuario.
            </p>
          </div>

          <div id="disclaimer" class="policy-section-container">
            <h2 class="section-wrap-title">Aviso de Exención de Responsabilidad y Limitaciones del Servicio</h2>
            <p class="section-container-paragraph">
              La Compañía se esfuerza por ofrecer información precisa, actualizada y relevante para la presentación de sus servicios. Sin embargo, no se garantiza la exactitud, integridad o vigencia de la información contenida en el sitio web. La utilización de cualquier contenido proporcionado en este sitio es responsabilidad exclusiva del usuario. En ningún caso la Compañía será responsable por daños directos, indirectos, incidentales, consecuentes o especiales, ni por pérdida de beneficios o datos, que sean resultado del uso o de la imposibilidad de utilizar nuestros servicios.
            </p>
            <p class="section-box-paragraph">
              El usuario reconoce y acepta que la información y los servicios disponibles a través del sitio web se ofrecen "tal cual" y "según disponibilidad", sin garantías explícitas o implícitas de ningún tipo, incluyendo, pero no limitándose a, garantías de comerciabilidad, idoneidad para un propósito particular o no infracción. La Compañía se reserva el derecho de modificar, actualizar o eliminar cualquier contenido de manera unilateral y sin previo aviso.
            </p>
            <p class="section-block-paragraph">
              Asimismo, la Compañía no se hace responsable de la veracidad, integridad y vigencia de terceros sitios o recursos enlazados, ni de posibles daños que pudieran derivarse de la interacción del usuario con dichos sitios y recursos. El usuario utiliza estos enlaces bajo su propio riesgo y discreción.
            </p>
          </div>

          <div id="personal-data" class="policy-section-wrap">
            <h2 class="section-box-title">Tratamiento de Datos Personales y Privacidad</h2>
            <p class="section-wrap-paragraph">
              En Andes Game Studio C.A. valoramos profundamente la privacidad y confidencialidad de la información personal de cada uno de nuestros usuarios. Toda la recopilación, almacenamiento y tratamiento de datos personales se realiza en estricto cumplimiento de las leyes locales vigentes, así como de las mejores prácticas internacionales en materia de protección de datos.
            </p>
            <p class="section-block-paragraph">
              La información personal recopilada a través del sitio web, la cual podrá incluir pero no limitarse a nombre, dirección IP, datos demográficos y de navegación, será utilizada únicamente con la finalidad de prestarle los servicios solicitados, mejorar la experiencia de usuario y garantizar la seguridad del proceso de interacción en el sitio.
            </p>
            <p class="section-box-paragraph">
              La Compañía se compromete a no vender, alquilar o ceder bajo ningún concepto la información personal obtenida a terceras partes, salvo que sea requerido por una autoridad competente o con el consentimiento expreso del usuario. En caso de que se requiera utilizar los datos personales para otros fines, se informará previamente al usuario y se solicitará su consentimiento explícito.
            </p>
            <p class="section-block-paragraph">
              Los usuarios disponen de derechos de acceso, rectificación, cancelación y oposición respecto a sus datos personales. Para ejercer estos derechos, el usuario podrá realizar una solicitud de eliminación o modificación de su información personal, la cual será atendida en los plazos establecidos por la normativa local. Es importante destacar que, en determinadas circunstancias, la eliminación total de la información no podrá llevarse a cabo si existe la obligación legal de conservar dicha información.
            </p>
            <p class="section-container-paragraph">
              La duración del almacenamiento de los datos personales se realizará por el tiempo estrictamente necesario para cumplir con las finalidades expuestas en nuestra política. Una vez finalizada esta finalidad, los datos serán eliminados de forma segura de nuestras bases de datos, a menos que una obligación legal requiera su conservación por un período mayor.
            </p>
          </div>

          <div id="cookies" class="policy-section-box">
            <h2 class="section-wrap-title">Uso de Cookies y Tecnologías Similares</h2>
            <p class="section-box-paragraph">
              Este sitio web utiliza cookies y tecnologías de seguimiento similares para mejorar la experiencia del usuario, personalizar contenido y analizar el tráfico. Las cookies son pequeños archivos de texto que se almacenan en el dispositivo del usuario y permiten recordar información sobre su visita, facilitando el acceso y la navegación en futuras ocasiones.
            </p>
            <p class="section-wrap-paragraph">
              La utilización de cookies tiene fines analíticos, de funcionalidad y, en algunos casos, de publicidad personalizada. La Compañía se compromete a utilizar estas herramientas en conformidad con las leyes locales, garantizando la protección de la información recopilada. En ningún caso utilizamos cookies para obtener datos sensibles sin el consentimiento explícito del usuario.
            </p>
            <p class="section-wrap-paragraph">
              El usuario puede gestionar o desactivar el uso de cookies modificando la configuración de su navegador. No obstante, la desactivación de cookies podría afectar el correcto funcionamiento del sitio y limitar algunas de las funcionalidades ofrecidas.
            </p>
            <p class="section-container-paragraph">
              En el caso de que se implemente algún mecanismo de consentimiento específico para el uso de cookies, se dispondrá de la información necesaria para que el usuario pueda tomar una decisión informada. Cualquier cambio en esta práctica será notificado de forma visible en el sitio web.
            </p>
          </div>

          <div id="data-security" class="policy-section-wrap">
            <h2 class="section-block-title">Medidas de Seguridad y Protección de Datos</h2>
            <p class="section-wrap-paragraph">
              La seguridad de sus datos personales y la protección contra accesos no autorizados es una prioridad para Andes Game Studio C.A.. Para ello, se han implementado protocolos y medidas de seguridad técnicas y organizativas que garantizan la integridad, confidencialidad y disponibilidad de la información.
            </p>
            <p class="section-box-paragraph">
              Entre las medidas de seguridad adoptadas se incluyen el uso de cifrado en la transmisión de datos, sistemas de autenticación robustos, y controles de acceso a las bases de datos. Además, se realizan evaluaciones periódicas para identificar y minimizar posibles vulnerabilidades.
            </p>
            <p class="section-container-paragraph">
              Sin embargo, es importante entender que ningún sistema es completamente infalible y, pese a nuestros esfuerzos constantes, siempre existe un riesgo residual. La Compañía no asume responsabilidad por incidentes derivados de ataques cibernéticos o accesos no autorizados, siempre y cuando se demuestre que se han adoptado las medidas de seguridad razonables y adecuadas en la materia.
            </p>
          </div>

          <div id="user-responsibilities" class="policy-section-block">
            <h2 class="section-container-title">Responsabilidades del Usuario y Uso Aceptable</h2>
            <p class="section-block-paragraph">
              Al utilizar los servicios de Andes Game Studio C.A., el usuario se compromete a hacerlo de manera lícita y a no realizar actividades que puedan dañar, interrumpir o interferir en el normal funcionamiento del sitio web y los servicios ofrecidos. Está terminantemente prohibido utilizar el sitio para actividades fraudulentas, difamatorias, ilegales o que infrinjan derechos de terceros.
            </p>
            <p class="section-box-paragraph">
              El usuario asume la responsabilidad de mantener la confidencialidad de las credenciales de acceso y de notificar de inmediato a la Compañía en caso de detectar cualquier uso no autorizado o actividad sospechosa en su cuenta. La omisión de este deber exime a Andes Game Studio C.A. de cualquier responsabilidad relacionada con el uso indebido de la cuenta.
            </p>
          </div>

          <div id="changes-policy" class="policy-section-container">
            <h2 class="section-box-title">Modificaciones y Actualizaciones de la Política</h2>
            <p class="section-wrap-paragraph">
              La Compañía se reserva el derecho de modificar, actualizar o suspender cualquier parte de esta exención de responsabilidad y política de privacidad en cualquier momento, sin necesidad de notificación previa. Todas las modificaciones serán debidamente publicadas en esta sección y entrar en vigor a partir de su fecha de publicación, indicada mediante el macro 2025-06-21.
            </p>
            <p class="section-box-paragraph">
              Es responsabilidad del usuario revisar periódicamente la versión actualizada de esta política. El uso continuado del sitio web después de la implementación de las modificaciones se interpretará como la aceptación de los cambios realizados.
            </p>
          </div>

          <div id="legal-information" class="policy-section-box">
            <h2 class="section-wrap-title">Información Legal y Cumplimiento Normativo</h2>
            <p class="section-wrap-paragraph">
              Esta exención de responsabilidad se rige por la legislación vigente en la jurisdicción aplicable, respetando en todo momento lo establecido en las leyes de protección de datos, privacidad y comercio electrónico. La Compañía se compromete a cumplir con las disposiciones legales relativas al tratamiento de datos personales, asegurando el respeto de la privacidad de los usuarios y la transparencia en el manejo de su información.
            </p>
            <p class="section-block-paragraph">
              Aunque en la jurisdicción aplicable no se exijan referencias obligatorias a normativas internacionales como el Reglamento General de Protección de Datos (GDPR), la Ley de Derechos y Protección de Datos Personales u otros marcos regulatorios similares, Andes Game Studio C.A. adopta prácticas y procedimientos acordes con dichos estándares de seguridad y transparencia, en aras de promover la confianza y seguridad de sus usuarios.
            </p>
            <p class="section-wrap-paragraph">
              La Compañía declara que no recopilará información personal sensible sin haber obtenido previamente el consentimiento explícito del usuario, y en los casos donde se requiera dicho consentimiento, se informará detalladamente al usuario sobre las finalidades y el tratamiento a que será sometida su información.
            </p>
          </div>

          <div id="limitations-liabilities" class="policy-section-block">
            <h2 class="section-container-title">Limitaciones de Responsabilidad y Exenciones Adicionales</h2>
            <p class="section-container-paragraph">
              Bajo ninguna circunstancia Andes Game Studio C.A. será responsable por los posibles errores, omisiones o interrupciones en el funcionamiento del sitio web, independientemente de si dichos fallos son atribuibles a mantenimiento, problemas técnicos, o a causas ajenas al control de la Compañía. La existencia de imprevistos técnicos o naturales que afecten el desempeño del sitio no exime al usuario de la obligación de leer y aceptar esta misma política para el uso de los servicios.
            </p>
            <p class="section-container-paragraph">
              Asimismo, la Compañía se exime de cualquier responsabilidad derivada de la utilización incorrecta de la información, interpretación errónea de los contenidos publicados o de la interacción con terceros, hecho que obliga al usuario a ejercer la debida diligencia y sentido crítico al hacer uso de los contenidos y servicios ofrecidos.
            </p>
            <p class="section-container-paragraph">
              En caso de que se demuestre negligencia o incumplimiento en la adopción de medidas de seguridad por parte de la Compañía, la responsabilidad estará limitada a la reparación del daño comprobable, siempre que dicho daño no derive de acciones voluntarias o maliciosas por parte del usuario.
            </p>
          </div>

          <div id="final-considerations" class="policy-section-container">
            <h2 class="section-container-title">Consideraciones Finales</h2>
            <p class="section-block-paragraph">
              Al utilizar los servicios de Andes Game Studio C.A., usted reconoce haber leído, entendido y aceptado íntegramente todas las cláusulas contenidas en este documento, asumiendo la plena responsabilidad por el uso que haga del sitio web y los servicios aquí descritos. La presente exención de responsabilidad se convierte en parte integral de cualquier acuerdo o transacción realizada a través del sitio, y su aceptación es indispensable para la utilización de los servicios.
            </p>
            <p class="section-container-paragraph">
              En caso de conflicto o duda en la interpretación de alguna de las cláusulas aquí contenidas, se procurará en primer lugar alcanzar una solución amistosa a través del diálogo y la negociación. De no ser posible, se someterá la controversia a la jurisdicción competente, de acuerdo con lo establecido en la normativa aplicable.
            </p>
            <p class="section-block-paragraph">
              Este documento fue actualizado el día 2025-06-21 y permanecerá vigente hasta nuevas actualizaciones que se efectuarán en el sitio. Se recomienda a todos los usuarios mantenerse informados sobre cualquier modificación que pudiera afectar sus derechos y obligaciones en relación con el uso de los servicios ofrecidos.
            </p>
            <p class="section-wrap-paragraph">
              Le agradecemos la confianza depositada en Andes Game Studio C.A.. Esperamos que la experiencia en nuestro sitio web sea satisfactoria y quedamos a su disposición para cualquier duda o aclaración que requiera en torno a estas condiciones.
            </p>
          </div>
        </div>
      </div>

    </div>
  </main>

  <!-- Footer Section -->
  <footer class="footer-section bg-dark-blue-gray text-white py-5" id='contact-form'>
    <div class="container text-center">
      <a class="footer-logo-link" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="mb-3" style="height: 50px;">
        <span class="fw-bold text-steel-white">Andes Game Studio</span>
      </a>
      <p class="mb-3 text-white-50">Andes Game Studio C.A. – Desarrollo de videojuegos móviles (iOS & Android)</p>
      <p class="mb-2 text-white-50"><i class="bi bi-geo-alt-fill me-2 text-primary-custom"></i>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</p>
      <p class="mb-2 text-white-50"><i class="bi bi-phone-fill me-2 text-primary-custom"></i>Teléfono: <a href="tel:+58 (212) 993-2140" class="text-white-50 text-decoration-none">+58 (212) 993-2140
        </a> | <a href="tel:+58 (424) 212-8326" class="text-white-50 text-decoration-none">+58 (424) 212-8326</a></p>
      <p class="mb-3 text-white-50"><i class="bi bi-envelope-fill me-2 text-primary-custom"></i>Email: <a href="mailto:studio_c.a._order@protonmail.com" class="text-white-50 text-decoration-none">studio_c.a._order@protonmail.com</a></p>

      <div class="social-icons mb-4">
        <a href="https://www.facebook.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-facebook fs-4"></i>
        </a>
        <a href="https://x.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-twitter-x fs-4"></i>
        </a>
        <a href="https://www.linkedin.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-linkedin fs-4"></i>
        </a>

      </div>

      <ul class="list-inline footer-links mb-4">
        <li class="list-inline-item"><a href="privacy-info.php" class="text-white-50 text-decoration-none">Política de Privacidad</a></li>
        <li class="list-inline-item"><a href="terms-of-service.php" class="text-white-50 text-decoration-none">Términos y Condiciones</a></li>
        <li class="list-inline-item"><a href="liability-disclaimer.php" class="text-white-50 text-decoration-none">Descargo de Responsabilidad</a></li>
        <li class="list-inline-item"><a href="cookie-preferences.php" class="text-white-50 text-decoration-none">Política de Cookies</a></li>
      </ul>

      <p class="mb-0 text-white-50">&copy; 2025 Andes Game Studio C.A. Todos los derechos reservados.</p>
    </div>
  </footer>

  <!-- Cookie Consent Modal -->
  <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content bg-white border-0 shadow-lg">
        <div class="modal-header border-0 pb-0">
          <h5 class="modal-title fw-bold text-steel-blue" id="cookieConsentModalLabel">Configuración de Cookies</h5>
        </div>
        <div class="modal-body p-4">
          <p class="text-secondary">Utilizamos cookies para mejorar tu experiencia de navegación, personalizar contenido y analizar nuestro tráfico. Al hacer clic en "Aceptar todo", aceptas el uso de todas las cookies. Puedes personalizar tus preferencias a continuación.</p>
          <p class="text-secondary small">Consulta nuestra <a href="cookie-preferences.php" class="text-primary-custom fw-bold">Política de Cookies</a> para más información.</p>

          <div id="cookieCategories" class="mt-3">
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="mandatoryCookies" checked disabled>
              <label class="form-check-label text-steel-blue fw-bold" for="mandatoryCookies">
                Obligatorias <span class="text-secondary">(Siempre activas)</span>
              </label>
              <p class="text-secondary small ms-4">Necesarias para el funcionamiento básico del sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="analyticsCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="analyticsCookies">
                Analíticas
              </label>
              <p class="text-secondary small ms-4">Nos ayudan a entender cómo los visitantes interactúan con el sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="marketingCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="marketingCookies">
                Marketing
              </label>
              <p class="text-secondary small ms-4">Utilizadas para mostrar anuncios relevantes basados en tus intereses.</p>
            </div>
          </div>

          <div class="d-flex justify-content-between mt-4">
            <button type="button" class="btn btn-outline-secondary" id="declineCookies">Rechazar</button>
            <button type="button" class="btn btn-primary-custom" id="acceptAllCookies">Aceptar Todo</button>
          </div>
          <div class="d-grid mt-3">
            <button type="button" class="btn btn-link text-primary-custom fw-bold" id="saveCookieSelection">Guardar Selección</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Popper.js (Required for Bootstrap JS) -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <!-- Bootstrap 5 JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
  <!-- Custom JavaScript -->
  <script src="frontend/script.js"></script>
</body>

</html>