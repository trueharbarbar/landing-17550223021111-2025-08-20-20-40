<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Andes Game Studio C.A. – Desarrollamos cautivadores juegos Match-3 para iOS y Android. Descubre nuestra pasión por la innovación y la diversión en cada nivel.">
    <meta name="keywords" content="Andes Game Studio, juegos Match-3, desarrollo de videojuegos, iOS, Android, juegos móviles, Caracas, Venezuela, estudio de juegos, entretenimiento digital">
    <title>Andes Game Studio C.A. | Desarrolladores de Juegos Match-3</title>
    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts (Poppins) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="frontend/style.css">
    <link rel="icon" type="image/svg+xml" href="frontend/pictures/andes-game-studio-favicon.svg">
</head>

<body class="bg-light-blue">

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="./">
                <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="me-2" style="height: 40px;">
                <span class="fw-bold text-steel-blue">Andes Game Studio</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="#hero">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="#about">Nosotros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="#services">Servicios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="#games">Juegos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="#team">Equipo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="#contact-form">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        <!-- Hero Section -->
        <section id="hero" class="hero-section d-flex align-items-center justify-content-center text-white text-center py-5 position-relative">
            <div class="hero-overlay"></div>
            <img src="frontend/pictures/pics/match3-hero-background.png" alt="Andes Game Studio Background" class="hero-bg-image position-absolute w-100 h-100 object-fit-cover">
            <div class="container position-relative z-1">
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8">
                        <h1 class="display-3 fw-bold mb-3">Andes Game Studio: Donde la Magia de los Match-3 Cobra Vida</h1>
                        <p class="lead mb-4">Creamos experiencias de juego Match-3 cautivadoras para iOS y Android, fusionando creatividad y tecnología para entretener a millones.</p>
                        <button type="button" class="btn btn-lg btn-primary-custom shadow-lg" data-bs-toggle="modal" data-bs-target="#contactModal">
                            ¡Hablemos de tu Próximo Juego!
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section id="about" class="about-section py-5">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Sobre Nosotros: Andes Game Studio C.A.</h2>
                <div class="row justify-content-center">
                    <div class="col-lg-10 col-md-12">
                        <div class="card shadow-sm border-0 mb-4">
                            <div class="card-body p-4">
                                <h3 class="h4 fw-bold text-steel-blue mb-3">Nuestra Historia</h3>
                                <p class="text-secondary">Fundada en 2018 en el corazón de Caracas, Venezuela, Andes Game Studio C.A. nació de una pasión compartida por los videojuegos y el deseo de crear experiencias móviles que resonaran con jugadores de todo el mundo. Desde nuestros humildes comienzos, hemos crecido, adaptándonos a las tendencias del mercado y perfeccionando nuestra artesanía en el desarrollo de juegos Match-3. Hemos lanzado exitosamente varios títulos que han sido descargados por millones, estableciéndonos como un referente en la industria regional.</p>
                                <img src="frontend/pictures/pics/andes-studio-team.jfif" alt="Equipo de Andes Game Studio" class="img-fluid rounded my-3">
                                <p class="text-secondary">Nuestro viaje ha estado marcado por la innovación y el compromiso con la calidad, siempre buscando nuevas formas de sorprender y deleitar a nuestra audiencia. Cada hito, desde el lanzamiento de nuestro primer juego hasta la expansión de nuestro equipo, ha fortalecido nuestra visión y nuestra dedicación a la comunidad de jugadores.</p>
                            </div>
                        </div>
                        <div class="card shadow-sm border-0 mb-4">
                            <div class="card-body p-4">
                                <h3 class="h4 fw-bold text-steel-blue mb-3">Misión y Valores</h3>
                                <p class="text-secondary">Nuestra misión es desarrollar juegos Match-3 innovadores y atractivos que ofrezcan diversión duradera y una experiencia de usuario impecable en plataformas iOS y Android. Nos esforzamos por ser líderes en creatividad y excelencia técnica, creando mundos vibrantes y desafíos adictivos que mantengan a los jugadores enganchados.</p>
                                <ul class="list-unstyled text-secondary">
                                    <li class="mb-2"><i class="bi bi-lightbulb-fill text-primary-custom me-2"></i><strong>Innovación:</strong> Siempre explorando nuevas mecánicas y narrativas.</li>
                                    <li class="mb-2"><i class="bi bi-controller text-primary-custom me-2"></i><strong>Orientación al Jugador:</strong> Ponemos al jugador en el centro de cada decisión de diseño.</li>
                                    <li class="mb-2"><i class="bi bi-award-fill text-primary-custom me-2"></i><strong>Calidad:</strong> Compromiso con la excelencia en cada aspecto del desarrollo.</li>
                                    <li class="mb-2"><i class="bi bi-people-fill text-primary-custom me-2"></i><strong>Colaboración:</strong> Fomentamos un ambiente de trabajo creativo y de apoyo.</li>
                                    <li class="mb-2"><i class="bi bi-shield-fill-check text-primary-custom me-2"></i><strong>Integridad:</strong> Operamos con honestidad y transparencia en todas nuestras interacciones.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Section (Accordion) -->
        <section id="services" class="services-section py-5 bg-alice-blue">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Nuestros Servicios de Desarrollo</h2>
                <div class="accordion accordion-flush" id="servicesAccordion">
                    <div class="accordion-item shadow-sm mb-3">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button fw-bold text-steel-blue collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                <i class="bi bi-puzzle-fill me-3 text-primary-custom"></i> Desarrollo de Juegos Match-3 Personalizados
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#servicesAccordion">
                            <div class="accordion-body text-secondary">
                                <p>Creamos juegos Match-3 desde cero, adaptándonos a tu visión y requisitos específicos. Desde la conceptualización hasta el lanzamiento, nuestro equipo experto se encarga de cada etapa del proceso de desarrollo, asegurando un producto final que supera las expectativas.</p>
                                <p>Incluye diseño de niveles, mecánicas de juego innovadoras, arte original y optimización de rendimiento para ambas plataformas móviles.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item shadow-sm mb-3">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button fw-bold text-steel-blue collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <i class="bi bi-brush-fill me-3 text-primary-custom"></i> Diseño de Arte y Animación para Juegos
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#servicesAccordion">
                            <div class="accordion-body text-secondary">
                                <p>Nuestro equipo de artistas talentosos da vida a tus ideas con gráficos vibrantes y animaciones fluidas. Nos especializamos en crear activos visuales atractivos que capturan la esencia de tu juego Match-3, desde personajes y objetos hasta fondos y efectos especiales.</p>
                                <p>Aseguramos una estética visual cohesiva y optimizada para dispositivos móviles.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item shadow-sm mb-3">
                        <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button fw-bold text-steel-blue collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                <i class="bi bi-soundwave me-3 text-primary-custom"></i> Diseño de Sonido y Música Original
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#servicesAccordion">
                            <div class="accordion-body text-secondary">
                                <p>La inmersión auditiva es clave. Ofrecemos servicios de diseño de sonido y composición de música original que complementan la experiencia de juego. Desde efectos de sonido satisfactorios para las combinaciones hasta bandas sonoras pegadizas que acompañan la aventura.</p>
                                <p>Creamos un paisaje sonoro único que mejora la jugabilidad y el engagement del usuario.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item shadow-sm mb-3">
                        <h2 class="accordion-header" id="headingFour">
                            <button class="accordion-button fw-bold text-steel-blue collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                <i class="bi bi-bug-fill me-3 text-primary-custom"></i> Pruebas y Aseguramiento de Calidad (QA)
                            </button>
                        </h2>
                        <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#servicesAccordion">
                            <div class="accordion-body text-secondary">
                                <p>Garantizamos que tu juego sea impecable antes del lanzamiento. Nuestro riguroso proceso de QA identifica y corrige errores, optimiza el rendimiento y asegura la compatibilidad en una amplia gama de dispositivos móviles.</p>
                                <p>Realizamos pruebas exhaustivas de funcionalidad, usabilidad y rendimiento para una experiencia de juego fluida.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Features Section (Key Aspects) -->
        <section id="features" class="features-section py-5">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Lo que Nos Hace Únicos</h2>
                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body text-center p-4">
                                <i class="bi bi-lightbulb display-4 text-primary-custom mb-3"></i>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Innovación Constante</h3>
                                <p class="text-secondary">Siempre a la vanguardia, exploramos nuevas mecánicas de juego y tendencias para ofrecer experiencias frescas y emocionantes.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body text-center p-4">
                                <i class="bi bi-gem display-4 text-primary-custom mb-3"></i>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Diseño de Niveles Adictivo</h3>
                                <p class="text-secondary">Nuestros niveles están meticulosamente diseñados para ser desafiantes, gratificantes y altamente rejugables, manteniendo a los jugadores enganchados.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body text-center p-4">
                                <i class="bi bi-palette display-4 text-primary-custom mb-3"></i>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Estilo Visual Cautivador</h3>
                                <p class="text-secondary">Creemos que el arte es fundamental. Nuestros juegos cuentan con gráficos vibrantes y personajes memorables que deleitan la vista.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body text-center p-4">
                                <i class="bi bi-phone display-4 text-primary-custom mb-3"></i>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Optimización Multiplataforma</h3>
                                <p class="text-secondary">Garantizamos un rendimiento fluido y una experiencia consistente en una amplia gama de dispositivos iOS y Android.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body text-center p-4">
                                <i class="bi bi-headphones display-4 text-primary-custom mb-3"></i>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Sonido y Música Inmersivos</h3>
                                <p class="text-secondary">El audio es clave para la inmersión. Nuestros juegos presentan bandas sonoras originales y efectos de sonido envolventes.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body text-center p-4">
                                <i class="bi bi-heart display-4 text-primary-custom mb-3"></i>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Pasión por los Juegos</h3>
                                <p class="text-secondary">Somos jugadores antes que desarrolladores. Nuestra pasión se refleja en cada detalle de los juegos que creamos.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Games Section (Latest/Popular) -->
        <section id="games" class="games-section py-5 bg-alice-blue">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Nuestros Juegos Destacados</h2>
                <div class="row g-4 justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100 shadow-sm border-0 game-card">
                            <img src="frontend/pictures/pics/joyas-del-amazonas.jpg" class="card-img-top" alt="Joyas del Amazonas">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Joyas del Amazonas</h3>
                                <p class="card-text text-secondary">Embárcate en una aventura épica a través de la selva amazónica, combinando gemas ancestrales para desvelar sus secretos.</p>
                                <div class="d-flex justify-content-center mt-3">
                                    <span class="badge bg-primary-custom me-2">Aventura</span>
                                    <span class="badge bg-secondary-custom">Puzle</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100 shadow-sm border-0 game-card">
                            <img src="frontend/pictures/pics/caracas-connect.png" class="card-img-top" alt="Caracas Connect">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Caracas Connect</h3>
                                <p class="card-text text-secondary">Un vibrante juego Match-3 inspirado en los coloridos barrios de Caracas, donde cada combinación te acerca a la cultura local.</p>
                                <div class="d-flex justify-content-center mt-3">
                                    <span class="badge bg-primary-custom me-2">Cultura</span>
                                    <span class="badge bg-secondary-custom">Casual</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100 shadow-sm border-0 game-card">
                            <img src="frontend/pictures/pics/aventura-andina.jpg" class="card-img-top" alt="Aventura Andina">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Aventura Andina</h3>
                                <p class="card-text text-secondary">Explora los majestuosos Andes en este desafiante juego de puzles, descubriendo tesoros ocultos y paisajes impresionantes.</p>
                                <div class="d-flex justify-content-center mt-3">
                                    <span class="badge bg-primary-custom me-2">Exploración</span>
                                    <span class="badge bg-secondary-custom">Estrategia</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section id="team" class="team-section py-5">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Conoce a Nuestro Equipo</h2>
                <div class="d-flex flex-wrap justify-content-center gap-4">
                    <div class="card team-card shadow-sm border-0 text-center">
                        <img src="frontend/pictures/sofia-rojas-avatar.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="Sofía Rojas">
                        <div class="card-body">
                            <h3 class="h5 fw-bold text-steel-blue mb-1">Sofía Rojas</h3>
                            <p class="text-primary-custom mb-0">CEO & Fundadora</p>
                            <p class="text-secondary small">Visión y Liderazgo</p>
                        </div>
                    </div>
                    <div class="card team-card shadow-sm border-0 text-center">
                        <img src="frontend/pictures/miguel-perez-avatar.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="Miguel Pérez">
                        <div class="card-body">
                            <h3 class="h5 fw-bold text-steel-blue mb-1">Miguel Pérez</h3>
                            <p class="text-primary-custom mb-0">Lead Developer</p>
                            <p class="text-secondary small">Ingeniería de Software</p>
                        </div>
                    </div>
                    <div class="card team-card shadow-sm border-0 text-center">
                        <img src="frontend/pictures/ana-garcia-avatar.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="Ana García">
                        <div class="card-body">
                            <h3 class="h5 fw-bold text-steel-blue mb-1">Ana García</h3>
                            <p class="text-primary-custom mb-0">Directora de Arte</p>
                            <p class="text-secondary small">Diseño Visual y UX</p>
                        </div>
                    </div>
                    <div class="card team-card shadow-sm border-0 text-center">
                        <img src="frontend/pictures/carlos-mendoza-avatar.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="Carlos Mendoza">
                        <div class="card-body">
                            <h3 class="h5 fw-bold text-steel-blue mb-1">Carlos Mendoza</h3>
                            <p class="text-primary-custom mb-0">Game Designer</p>
                            <p class="text-secondary small">Mecánicas y Niveles</p>
                        </div>
                    </div>
                    <div class="card team-card shadow-sm border-0 text-center">
                        <img src="frontend/pictures/laura-gomez-avatar.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="Laura Gómez">
                        <div class="card-body">
                            <h3 class="h5 fw-bold text-steel-blue mb-1">Laura Gómez</h3>
                            <p class="text-primary-custom mb-0">QA Lead</p>
                            <p class="text-secondary small">Aseguramiento de Calidad</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats Section -->
        <section id="stats" class="stats-section py-5 bg-steel-blue text-white text-center">
            <div class="container">
                <h2 class="display-5 fw-bold mb-5">Nuestro Impacto en Números</h2>
                <div class="row">
                    <div class="col-md-4 mb-4 mb-md-0">
                        <div class="stat-item">
                            <i class="bi bi-clock-history display-4 mb-3 text-primary-custom"></i>
                            <p class="display-4 fw-bold mb-1">+7</p>
                            <p class="lead">Años de Experiencia</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4 mb-md-0">
                        <div class="stat-item">
                            <i class="bi bi-controller display-4 mb-3 text-primary-custom"></i>
                            <p class="display-4 fw-bold mb-1">+5</p>
                            <p class="lead">Juegos Publicados</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-item">
                            <i class="bi bi-download display-4 mb-3 text-primary-custom"></i>
                            <p class="display-4 fw-bold mb-1">+15M</p>
                            <p class="lead">Descargas Globales</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Industries Section (Announcements/Events) -->
        <section id="industries" class="industries-section py-5 bg-alice-blue">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Noticias y Eventos</h2>
                <div class="row g-4 justify-content-center">
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <span class="badge bg-primary-custom mb-3">Anuncio de Juego</span>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Próximo Lanzamiento: "Misterio de la Gran Sabana"</h3>
                                <p class="text-secondary small mb-2">Fecha: 15 de julio de 2025</p>
                                <p class="card-text text-secondary">Prepárense para una nueva aventura Match-3 inspirada en los paisajes de la Gran Sabana. ¡Más detalles pronto!</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <span class="badge bg-secondary-custom mb-3">Actualización</span>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Actualización Mayor para "Joyas del Amazonas"</h3>
                                <p class="text-secondary small mb-2">Fecha: 20 de junio de 2025</p>
                                <p class="card-text text-secondary">Nuevos niveles, potenciadores y eventos especiales ya disponibles en la última actualización. ¡Descárgala ahora!</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <span class="badge bg-primary-custom mb-3">Evento</span>
                                <h3 class="h5 fw-bold text-steel-blue mb-2">Participación en Venezuela Game Show 2025</h3>
                                <p class="text-secondary small mb-2">Fecha: 1-3 de agosto de 2025</p>
                                <p class="card-text text-secondary">Visítanos en nuestro stand para probar demos exclusivos y conocer al equipo. ¡Te esperamos!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- FAQ Section -->
        <section id="faq" class="faq-section py-5">
            <div class="container">
                <h2 class="text-center display-5 fw-bold mb-5 text-steel-blue">Preguntas Frecuentes</h2>
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2"><i class="bi bi-question-circle-fill me-2 text-primary-custom"></i> ¿Qué tipo de juegos desarrollan?</h3>
                                <p class="text-secondary">Nos especializamos en el desarrollo de juegos Match-3 para plataformas móviles (iOS y Android), creando experiencias adictivas y visualmente atractivas.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2"><i class="bi bi-question-circle-fill me-2 text-primary-custom"></i> ¿Pueden desarrollar un juego a medida?</h3>
                                <p class="text-secondary">Sí, ofrecemos servicios de desarrollo de juegos personalizados. Trabajamos de cerca contigo para transformar tu idea en un juego Match-3 único y exitoso.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2"><i class="bi bi-question-circle-fill me-2 text-primary-custom"></i> ¿Cuál es el proceso de desarrollo?</h3>
                                <p class="text-secondary">Nuestro proceso incluye conceptualización, diseño, desarrollo, pruebas de calidad, y lanzamiento. Mantenemos una comunicación constante con el cliente en cada etapa.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card h-100 shadow-sm border-0 bg-white">
                            <div class="card-body p-4">
                                <h3 class="h5 fw-bold text-steel-blue mb-2"><i class="bi bi-question-circle-fill me-2 text-primary-custom"></i> ¿Ofrecen soporte post-lanzamiento?</h3>
                                <p class="text-secondary">Absolutamente. Proporcionamos soporte y mantenimiento continuos para asegurar que tu juego siga funcionando de manera óptima y reciba actualizaciones necesarias.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section (Banner CTA) -->
        <section id="contact-banner" class="contact-banner-section py-5 text-center text-white position-relative">
            <div class="contact-overlay"></div>
            <img src="frontend/pictures/pics/contact-banner-match3.png" alt="Contact Us Background" class="contact-bg-image position-absolute w-100 h-100 object-fit-cover">
            <div class="container position-relative z-1">
                <h2 class="display-5 fw-bold mb-4">¿Tienes una Idea Brillante?</h2>
                <p class="lead mb-5">Estamos listos para transformar tu visión en el próximo éxito de los juegos Match-3.</p>
                <button type="button" class="btn btn-lg btn-primary-custom shadow-lg" data-bs-toggle="modal" data-bs-target="#contactModal">
                    ¡Contáctanos Ahora!
                </button>
            </div>
        </section>

        <!-- Contact Modal -->
        <div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content bg-alice-blue border-0 shadow-lg">
                    <div class="modal-header border-0 pb-0">
                        <h5 class="modal-title fw-bold text-steel-blue" id="contactModalLabel">Solicita una Consulta</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-4">
                        <form id="contactForm" action="counseling-thankyou.php" method="POST" novalidate>
                            <div class="mb-3">
                                <label for="fullName" class="form-label text-steel-blue">Nombre Completo <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Ej: Juan Pérez" required>
                                <div class="invalid-feedback">Por favor, introduce tu nombre completo.</div>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label text-steel-blue">Correo Electrónico <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Ej: tu.correo@ejemplo.com" required>
                                <div class="invalid-feedback">Por favor, introduce un correo electrónico válido.</div>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label text-steel-blue">Número de Teléfono</label>
                                <input type="tel" class="form-control" id="phone" name="phone" placeholder="Ej: +58 412 1234567">
                                <div class="invalid-feedback">Por favor, introduce un número de teléfono válido.</div>
                            </div>
                            <div class="mb-3">
                                <label for="projectIdea" class="form-label text-steel-blue">Cuéntanos sobre tu Idea de Proyecto <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="projectIdea" name="projectIdea" rows="5" placeholder="Describe tu visión para el juego Match-3..." required></textarea>
                                <div class="invalid-feedback">Por favor, describe tu idea de proyecto.</div>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" id="privacyConsent" name="privacyConsent" required>
                                <label class="form-check-label text-secondary" for="privacyConsent">
                                    Acepto la <a href="privacy-info.php" class="text-primary-custom fw-bold">Política de Privacidad</a> <span class="text-danger">*</span>
                                </label>
                                <div class="invalid-feedback">Debes aceptar la política de privacidad.</div>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary-custom btn-lg">Enviar Solicitud</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </main>

    <!-- Footer Section -->
    <footer class="footer-section bg-dark-blue-gray text-white py-5" id='contact-form'>
        <div class="container text-center">
            <a class="footer-logo-link" href="./">
                <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="mb-3" style="height: 50px;">
                <span class="fw-bold text-steel-white">Andes Game Studio</span>
            </a>
            <p class="mb-3 text-white-50">Andes Game Studio C.A. – Desarrollo de videojuegos móviles (iOS & Android)</p>
            <p class="mb-2 text-white-50"><i class="bi bi-geo-alt-fill me-2 text-primary-custom"></i>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</p>
            <p class="mb-2 text-white-50"><i class="bi bi-phone-fill me-2 text-primary-custom"></i>Teléfono: <a href="tel:+58 (212) 993-2140" class="text-white-50 text-decoration-none">+58 (212) 993-2140
                </a> | <a href="tel:+58 (424) 212-8326" class="text-white-50 text-decoration-none">+58 (424) 212-8326</a></p>
            <p class="mb-3 text-white-50"><i class="bi bi-envelope-fill me-2 text-primary-custom"></i>Email: <a href="mailto:studio_c.a._order@protonmail.com" class="text-white-50 text-decoration-none">studio_c.a._order@protonmail.com</a></p>

            <div class="social-icons mb-4">
                <a href="https://www.facebook.com" target="_blank" class="text-white mx-2">
                    <i class="bi bi-facebook fs-4"></i>
                </a>
                <a href="https://x.com" target="_blank" class="text-white mx-2">
                    <i class="bi bi-twitter-x fs-4"></i>
                </a>
                <a href="https://www.linkedin.com" target="_blank" class="text-white mx-2">
                    <i class="bi bi-linkedin fs-4"></i>
                </a>

            </div>

            <ul class="list-inline footer-links mb-4">
                <li class="list-inline-item"><a href="privacy-info.php" class="text-white-50 text-decoration-none">Política de Privacidad</a></li>
                <li class="list-inline-item"><a href="terms-of-service.php" class="text-white-50 text-decoration-none">Términos y Condiciones</a></li>
                <li class="list-inline-item"><a href="liability-disclaimer.php" class="text-white-50 text-decoration-none">Descargo de Responsabilidad</a></li>
                <li class="list-inline-item"><a href="cookie-preferences.php" class="text-white-50 text-decoration-none">Política de Cookies</a></li>
            </ul>

            <p class="mb-0 text-white-50">&copy; 2025 Andes Game Studio C.A. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Cookie Consent Modal -->
    <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-white border-0 shadow-lg">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-steel-blue" id="cookieConsentModalLabel">Configuración de Cookies</h5>
                </div>
                <div class="modal-body p-4">
                    <p class="text-secondary">Utilizamos cookies para mejorar tu experiencia de navegación, personalizar contenido y analizar nuestro tráfico. Al hacer clic en "Aceptar todo", aceptas el uso de todas las cookies. Puedes personalizar tus preferencias a continuación.</p>
                    <p class="text-secondary small">Consulta nuestra <a href="cookie-preferences.php" class="text-primary-custom fw-bold">Política de Cookies</a> para más información.</p>

                    <div id="cookieCategories" class="mt-3">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="mandatoryCookies" checked disabled>
                            <label class="form-check-label text-steel-blue fw-bold" for="mandatoryCookies">
                                Obligatorias <span class="text-secondary">(Siempre activas)</span>
                            </label>
                            <p class="text-secondary small ms-4">Necesarias para el funcionamiento básico del sitio.</p>
                        </div>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="analyticsCookies">
                            <label class="form-check-label text-steel-blue fw-bold" for="analyticsCookies">
                                Analíticas
                            </label>
                            <p class="text-secondary small ms-4">Nos ayudan a entender cómo los visitantes interactúan con el sitio.</p>
                        </div>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="marketingCookies">
                            <label class="form-check-label text-steel-blue fw-bold" for="marketingCookies">
                                Marketing
                            </label>
                            <p class="text-secondary small ms-4">Utilizadas para mostrar anuncios relevantes basados en tus intereses.</p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary" id="declineCookies">Rechazar</button>
                        <button type="button" class="btn btn-primary-custom" id="acceptAllCookies">Aceptar Todo</button>
                    </div>
                    <div class="d-grid mt-3">
                        <button type="button" class="btn btn-link text-primary-custom fw-bold" id="saveCookieSelection">Guardar Selección</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Popper.js (Required for Bootstrap JS) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="frontend/script.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            if (sessionStorage.getItem('openContactModal') === 'true') {
                sessionStorage.removeItem('openContactModal'); // чтобы не повторялось
                var myModal = new bootstrap.Modal(document.getElementById('contactModal'));
                myModal.show();
            }
        });
    </script>


</body>

</html>