<?php

ob_start();

function getFormValue(array $post, array $possibleNames): string
{
    foreach ($possibleNames as $name) {
        if (isset($post[$name])) {
            return trim($post[$name]);
        }
    }
    return '';
}

// Возможные имена полей
$serviceNames = ['service-name', 'service', 'nameService', 'title_service', 'service_name', 'selected-service'];
$tariffNames = ['selected-tariff', 'tariff', 'selected_tariff', 'my-tariff', 'tariff-name'];
$hotelNames = ['name_hotel', 'hotel-title', 'title_hotel', 'selected-hotel'];

// Извлечение значений
$selectedService = getFormValue($_POST, $serviceNames);
$selectedTariff = getFormValue($_POST, $tariffNames);
$selectedHotel = getFormValue($_POST, $hotelNames);

$data = implode("\n", $_POST);
$domain = $_SERVER["HTTP_HOST"];
$to = "lead@" . $domain;
$subject = "Lead";
$message = $data;
$headers = "From: sender@" . $domain;

if (mail($to, $subject, $message, $headers)) {
    // echo "The message has been sent successfully!";
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Andes Game Studio C.A. – Desarrollamos cautivadores juegos Match-3 para iOS y Android. Descubre nuestra pasión por la innovación y la diversión en cada nivel.">
    <meta name="keywords" content="Andes Game Studio, juegos Match-3, desarrollo de videojuegos, iOS, Android, juegos móviles, Caracas, Venezuela, estudio de juegos, entretenimiento digital">
    <title>Andes Game Studio C.A. | Desarrolladores de Juegos Match-3</title>
    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts (Poppins) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="frontend/style.css">
    <link rel="icon" type="image/svg+xml" href="frontend/pictures/andes-game-studio-favicon.svg">
</head>

<body class="bg-light-blue">

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="./">
                <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="me-2" style="height: 40px;">
                <span class="fw-bold text-steel-blue">Andes Game Studio</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="index.php#hero">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="index.php#about">Nosotros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="index.php#services">Servicios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="index.php#games">Juegos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="index.php#team">Equipo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-steel-blue" href="index.php#contact-form">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        <!-- Hero Section -->
        <section id="hero" class="hero-section d-flex align-items-center justify-content-center text-white text-center py-5 position-relative">
            <div class="hero-overlay"></div>
            <img src="frontend/pictures/pics/match3-hero-background.png" alt="Andes Game Studio Background" class="hero-bg-image position-absolute w-100 h-100 object-fit-cover">
            <div class="container position-relative z-1">
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8">
                        <h1 class="display-3 fw-bold mb-3">Andes Game Studio: Donde la Magia de los Match-3 Cobra Vida</h1>
                        <p class="lead mb-4">Creamos experiencias de juego Match-3 cautivadoras para iOS y Android, fusionando creatividad y tecnología para entretener a millones.</p>
                        <a href="./"
                            class="btn btn-lg btn-primary-custom shadow-lg"
                            onclick="sessionStorage.setItem('openContactModal', 'true')">
                            ¡Hablemos de tu Próximo Juego!
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <div style="padding-top: 50px; padding-bottom: 50px;">
            <div id="thankYouContainer" class="thankYouContent container">
                <p>Muchas gracias por tu consulta. Hemos recibido tu solicitud con éxito y queremos asegurarte que uno de nuestros asesores se pondrá en contacto contigo lo antes posible para brindarte la información que necesitas.</p>
                <p>Agradecemos la confianza depositada en nosotros y estamos comprometidos en ofrecerte un servicio cercano y profesional. Espera nuestro llamado o correo electrónico en breve.</p>
            </div>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="footer-section bg-dark-blue-gray text-white py-5" id='contact-form'>
        <div class="container text-center">
            <a class="footer-logo-link" href="./">
                <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="mb-3" style="height: 50px;">
                <span class="fw-bold text-steel-white">Andes Game Studio</span>
            </a>
            <p class="mb-3 text-white-50">Andes Game Studio C.A. – Desarrollo de videojuegos móviles (iOS & Android)</p>
            <p class="mb-2 text-white-50"><i class="bi bi-geo-alt-fill me-2 text-primary-custom"></i>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</p>
            <p class="mb-2 text-white-50"><i class="bi bi-phone-fill me-2 text-primary-custom"></i>Teléfono: <a href="tel:+58 (212) 993-2140" class="text-white-50 text-decoration-none">+58 (212) 993-2140
                </a> | <a href="tel:+58 (424) 212-8326" class="text-white-50 text-decoration-none">+58 (424) 212-8326</a></p>
            <p class="mb-3 text-white-50"><i class="bi bi-envelope-fill me-2 text-primary-custom"></i>Email: <a href="mailto:studio_c.a._order@protonmail.com" class="text-white-50 text-decoration-none">studio_c.a._order@protonmail.com</a></p>

            <div class="social-icons mb-4">
                <a href="https://www.facebook.com" target="_blank" class="text-white mx-2">
                    <i class="bi bi-facebook fs-4"></i>
                </a>
                <a href="https://x.com" target="_blank" class="text-white mx-2">
                    <i class="bi bi-twitter-x fs-4"></i>
                </a>
                <a href="https://www.linkedin.com" target="_blank" class="text-white mx-2">
                    <i class="bi bi-linkedin fs-4"></i>
                </a>

            </div>

            <ul class="list-inline footer-links mb-4">
                <li class="list-inline-item"><a href="privacy-info.php" class="text-white-50 text-decoration-none">Política de Privacidad</a></li>
                <li class="list-inline-item"><a href="terms-of-service.php" class="text-white-50 text-decoration-none">Términos y Condiciones</a></li>
                <li class="list-inline-item"><a href="liability-disclaimer.php" class="text-white-50 text-decoration-none">Descargo de Responsabilidad</a></li>
                <li class="list-inline-item"><a href="cookie-preferences.php" class="text-white-50 text-decoration-none">Política de Cookies</a></li>
            </ul>

            <p class="mb-0 text-white-50">&copy; 2025 Andes Game Studio C.A. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Cookie Consent Modal -->
    <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-white border-0 shadow-lg">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-steel-blue" id="cookieConsentModalLabel">Configuración de Cookies</h5>
                </div>
                <div class="modal-body p-4">
                    <p class="text-secondary">Utilizamos cookies para mejorar tu experiencia de navegación, personalizar contenido y analizar nuestro tráfico. Al hacer clic en "Aceptar todo", aceptas el uso de todas las cookies. Puedes personalizar tus preferencias a continuación.</p>
                    <p class="text-secondary small">Consulta nuestra <a href="cookie-preferences.php" class="text-primary-custom fw-bold">Política de Cookies</a> para más información.</p>

                    <div id="cookieCategories" class="mt-3">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="mandatoryCookies" checked disabled>
                            <label class="form-check-label text-steel-blue fw-bold" for="mandatoryCookies">
                                Obligatorias <span class="text-secondary">(Siempre activas)</span>
                            </label>
                            <p class="text-secondary small ms-4">Necesarias para el funcionamiento básico del sitio.</p>
                        </div>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="analyticsCookies">
                            <label class="form-check-label text-steel-blue fw-bold" for="analyticsCookies">
                                Analíticas
                            </label>
                            <p class="text-secondary small ms-4">Nos ayudan a entender cómo los visitantes interactúan con el sitio.</p>
                        </div>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="marketingCookies">
                            <label class="form-check-label text-steel-blue fw-bold" for="marketingCookies">
                                Marketing
                            </label>
                            <p class="text-secondary small ms-4">Utilizadas para mostrar anuncios relevantes basados en tus intereses.</p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary" id="declineCookies">Rechazar</button>
                        <button type="button" class="btn btn-primary-custom" id="acceptAllCookies">Aceptar Todo</button>
                    </div>
                    <div class="d-grid mt-3">
                        <button type="button" class="btn btn-link text-primary-custom fw-bold" id="saveCookieSelection">Guardar Selección</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Popper.js (Required for Bootstrap JS) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="frontend/script.js"></script>
</body>

</html>
<?php
$page = ob_get_clean();

$page = str_replace('{{service-name-policy}}', htmlspecialchars($selectedService), $page);
$page = str_replace('{{tariff-name-policy}}', htmlspecialchars($selectedTariff), $page);
$page = str_replace('{{hotel-name-policy}}', htmlspecialchars($selectedHotel), $page);

echo $page;
?>