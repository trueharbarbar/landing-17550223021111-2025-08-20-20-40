<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Andes Game Studio C.A. – Desarrollamos cautivadores juegos Match-3 para iOS y Android. Descubre nuestra pasión por la innovación y la diversión en cada nivel.">
  <meta name="keywords" content="Andes Game Studio, juegos Match-3, desarrollo de videojuegos, iOS, Android, juegos móviles, Caracas, Venezuela, estudio de juegos, entretenimiento digital">
  <title>Andes Game Studio C.A. | Desarrolladores de Juegos Match-3</title>
  <!-- Bootstrap 5 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts (Poppins) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="frontend/style.css">
  <link rel="icon" type="image/svg+xml" href="frontend/pictures/andes-game-studio-favicon.svg">
</head>

<body class="bg-light-blue">

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="me-2" style="height: 40px;">
        <span class="fw-bold text-steel-blue">Andes Game Studio</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#hero">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#about">Nosotros</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#services">Servicios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#games">Juegos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#team">Equipo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#contact-form">Contacto</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- Hero Section -->
    <section id="hero" class="hero-section d-flex align-items-center justify-content-center text-white text-center py-5 position-relative">
      <div class="hero-overlay"></div>
      <img src="frontend/pictures/pics/match3-hero-background.png" alt="Andes Game Studio Background" class="hero-bg-image position-absolute w-100 h-100 object-fit-cover">
      <div class="container position-relative z-1">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-8">
            <h1 class="display-3 fw-bold mb-3">Andes Game Studio: Donde la Magia de los Match-3 Cobra Vida</h1>
            <p class="lead mb-4">Creamos experiencias de juego Match-3 cautivadoras para iOS y Android, fusionando creatividad y tecnología para entretener a millones.</p>
            <a href="./"
              class="btn btn-lg btn-primary-custom shadow-lg"
              onclick="sessionStorage.setItem('openContactModal', 'true')">
              ¡Hablemos de tu Próximo Juego!
            </a>
          </div>
        </div>
      </div>
    </section>

    <div style="padding-top: 50px; padding-bottom: 50px;">

      <div class="rightsCloudWrap">
        <div class="policy-container" id="privacy-policy">
          <h2 class="policy-title" id="section-introduction">Introducción</h2>
          <p class="policy-paragraph" id="intro-text">
            Bienvenido a la política de privacidad de Andes Game Studio C.A.. En Andes Game Studio C.A., nos comprometemos a proteger la privacidad y seguridad de la información personal de nuestros clientes y usuarios. El presente documento describe en detalle cómo recopilamos, utilizamos, almacenamos y protegemos la información personal que usted nos proporciona al utilizar nuestros servicios, así como sus derechos de acceso, rectificación y supresión de dichos datos. Esta política ha sido elaborada conforme a la normativa vigente en la República Bolivariana de Venezuela (VE), tomando en cuenta las formalidades y disposiciones legales que rigen en materia de protección de datos personales. Le invitamos a leer detenidamente el presente documento para que comprenda cómo se gestionan sus datos y las medidas que hemos adoptado en aras de garantizar la confidencialidad y seguridad de su información.
          </p>

          <h2 class="policy-title" id="section-data-collection">Recopilación de Datos Personales</h2>
          <p class="policy-paragraph" id="data-collection-text">
            Al utilizar los servicios ofrecidos en nuestra página de servicios, es posible que recopilemos diversos tipos de información personal, tales como nombres, direcciones de correo electrónico, números telefónicos, direcciones físicas y otros datos que usted facilite voluntariamente. Esta información es necesaria para operar correctamente nuestros servicios, responder a sus consultas, gestionar solicitudes y mejorar su experiencia de usuario. La recopilación se realiza de manera lícita, transparente y con el fin específico de cumplir con las obligaciones contractuales y mejorar continuamente la relación entre el usuario y Andes Game Studio C.A..
          </p>

          <h2 class="policy-title" id="section-purpose">Finalidad del Tratamiento de Datos</h2>
          <p class="policy-paragraph" id="purpose-text">
            Los datos recopilados serán utilizados para las siguientes finalidades:
          </p>
          <ul class="policy-list" id="data-use-list">
            <li class="policy-list-item">Gestionar y ejecutar solicitudes de servicios, consultas o reclamos.</li>
            <li class="policy-list-item">Mejorar la calidad de nuestros servicios y optimizar la experiencia del usuario.</li>
            <li class="policy-list-item">Enviar información relevante, notificaciones y actualizaciones acerca de nuestros productos y servicios, siempre que usted haya dado su consentimiento expreso para recibir dichas comunicaciones.</li>
            <li class="policy-list-item">Cumplir con obligaciones legales, contractuales y desarrollar investigaciones internas para velar por nuestros estándares de seguridad y calidad.</li>
          </ul>

          <h2 class="policy-title" id="section-legal-base">Base Legal para el Tratamiento de Datos</h2>
          <p class="policy-paragraph" id="legal-base-text">
            El tratamiento de sus datos se fundamenta en el consentimiento del usuario, la ejecución de la relación contractual y el legítimo interés de Andes Game Studio C.A. para garantizar la prestación adecuada de nuestros servicios. Asimismo, en cumplimiento con la normativa venezolana en materia de protección de datos personales, nos comprometemos a tratar la información de forma ética y responsable, garantizando el respeto a sus derechos fundamentales.
          </p>

          <h2 class="policy-title" id="section-access-rights">Acceso, Rectificación y Eliminación de Datos</h2>
          <p class="policy-paragraph" id="access-rights-intro">
            Usted tiene el derecho de solicitar en cualquier momento el acceso, la rectificación o la eliminación de la información personal que hemos recopilado sobre usted. Este derecho se ejerce libremente y puede ser solicitado mediante un requerimiento formal dirigido a Andes Game Studio C.A.. A continuación, se detalla el proceso y alcance de estos derechos:
          </p>
          <ul class="policy-list" id="rights-list">
            <li class="policy-list-item">
              <strong>Acceso:</strong> Usted puede solicitar una copia de los datos personales que tenemos almacenados, así como información sobre el uso y las finalidades para las que dichos datos están siendo procesados.
            </li>
            <li class="policy-list-item">
              <strong>Rectificación:</strong> En caso de que detecte información inexacta o desactualizada, podrá solicitar que se realicen las correcciones pertinentes para reflejar fielmente sus datos.
            </li>
            <li class="policy-list-item">
              <strong>Eliminación:</strong> Usted puede solicitar la supresión de sus datos personales de nuestros registros, siempre que no exista una obligación legal que nos obligue a conservar dichos datos. Es importante tener en cuenta que la eliminación de datos podría afectar la prestación de ciertos servicios o la conservación de registros necesarios para fines legales o contractuales.
            </li>
          </ul>
          <p class="policy-paragraph" id="rights-contact-info">
            Para ejercer cualquiera de estos derechos, por favor póngase en contacto utilizando nuestros canales oficiales: teléfono: +58 (212) 993-2140
            +58 (424) 212-8326, correo electrónico: studio_c.a._order@protonmail.com o dirección física: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela. Todas las solicitudes serán atendidas en un plazo razonable y conforme a lo establecido en la legislación vigente.
          </p>

          <h2 class="policy-title" id="section-data-retention">Conservación y Eliminación de Datos</h2>
          <p class="policy-paragraph" id="data-retention-text">
            Andes Game Studio C.A. retendrá sus datos personales durante el tiempo que sea necesario para cumplir con las finalidades para las que fueron recabados, y en todo caso, mientras se mantenga la relación contractual. Una vez cumplido el plazo o terminado el servicio, los datos se eliminarán de forma segura, a menos que la ley requiera un periodo mayor de conservación para el cumplimiento de obligaciones legales o para la defensa de intereses legítimos de la empresa.
          </p>

          <h2 class="policy-title" id="section-data-security">Seguridad de la Información</h2>
          <p class="policy-paragraph" id="data-security-text">
            La protección de sus datos personales es de suma importancia para nosotros. En Andes Game Studio C.A. implementamos medidas de seguridad técnicas y organizativas que cumplen con estándares internacionales para proteger la integridad, confidencialidad y disponibilidad de la información. Entre las medidas adoptadas se encuentran:
          </p>
          <ul class="policy-list" id="security-measures-list">
            <li class="policy-list-item">Cifrado de datos durante la transmisión y almacenamiento.</li>
            <li class="policy-list-item">Sistemas de control de acceso robustos para prevenir accesos no autorizados.</li>
            <li class="policy-list-item">Monitoreo continuo y protocolos de respuesta ante incidentes de seguridad.</li>
            <li class="policy-list-item">Revisión y actualización periódica de nuestras políticas y medidas de seguridad en función de la evolución tecnológica y de las amenazas emergentes.</li>
          </ul>
          <p class="policy-paragraph" id="security-responsibilities">
            Pese a estas medidas, es importante señalar que ningún sistema es completamente infalible. Sin embargo, nos comprometemos a notificarle de forma inmediata cualquier brecha de seguridad que pudiera comprometer sus datos personales, y a tomar las medidas correctivas pertinentes para mitigar cualquier riesgo.
          </p>

          <h2 class="policy-title" id="section-cookies">Uso de Cookies y Tecnologías Similares</h2>
          <p class="policy-paragraph" id="cookies-intro">
            Con el objetivo de mejorar la experiencia del usuario y facilitar la navegación en nuestro sitio, Andes Game Studio C.A. utiliza cookies y otras tecnologías de rastreo. Estas herramientas permiten almacenar y recuperar información sobre las interacciones del usuario con el sitio web. Las cookies pueden ser clasificadas en:
          </p>
          <ul class="policy-list" id="cookies-types">
            <li class="policy-list-item"><strong>Cookies Esenciales:</strong> Son necesarias para el funcionamiento del sitio y la prestación de los servicios solicitados. Sin ellas, partes del sitio podrían no funcionar correctamente.</li>
            <li class="policy-list-item"><strong>Cookies de Preferencias:</strong> Permiten recordar las elecciones o preferencias que usted realiza al interactuar con el sitio, facilitando una experiencia personalizada.</li>
            <li class="policy-list-item"><strong>Cookies de Análisis:</strong> Ayudan a recopilar datos estadísticos y de comportamiento para mejorar la oferta de servicios y optimizar el rendimiento del sitio web.</li>
            <li class="policy-list-item"><strong>Cookies de Publicidad:</strong> Se utilizan para mostrar anuncios relevantes y personalizados en función de su comportamiento e intereses. Estas cookies pueden ser gestionadas a través de nuestras configuraciones de privacidad.</li>
          </ul>
          <p class="policy-paragraph" id="cookies-management">
            Usted puede gestionar sus preferencias sobre el uso de cookies mediante la configuración de su navegador o utilizando las herramientas que ponemos a disposición en el sitio. Si decide bloquear o eliminar las cookies, es posible que algunas funcionalidades del sitio se vean afectadas. Le recomendamos que revise periódicamente esta sección para estar informado acerca de las actualizaciones de nuestra política de cookies.
          </p>

          <h2 class="policy-title" id="section-third-parties">Divulgación de Datos a Terceros</h2>
          <p class="policy-paragraph" id="third-parties-text">
            En Andes Game Studio C.A. nos comprometemos a no vender, ceder o alquilar su información personal a terceros sin su consentimiento expreso, salvo en aquellos casos en los que sea necesario para cumplir con obligaciones legales, contractuales o en el marco de relaciones necesarias para la prestación de nuestros servicios (por ejemplo, proveedores de servicios de pago o hosting). Cuando se produzca el intercambio de datos a terceros, se garantizará que estos cumplan con las medidas de seguridad y confidencialidad equiparables a las establecidas por nuestra política interna.
          </p>

          <h2 class="policy-title" id="section-changes-policy">Modificaciones a la Política de Privacidad</h2>
          <p class="policy-paragraph" id="policy-updates-text">
            La versión vigente de esta Política de Privacidad es la publicada en 2025-07-15. En Andes Game Studio C.A. nos reservamos el derecho de modificar esta política en cualquier momento, publicando la versión actualizada en nuestro sitio web. Cualquier cambio significativo será notificado a los usuarios a través de nuestros canales oficiales y se tendrá en cuenta la compatibilidad con la normativa venezolana vigente. Se recomienda revisar periódicamente la política para mantenerse informado de las modificaciones y de la forma en que estas puedan afectar el tratamiento de sus datos.
          </p>

          <h2 class="policy-title" id="section-user-responsibilities">Responsabilidades del Usuario</h2>
          <p class="policy-paragraph" id="user-responsibilities-text">
            Es importante que el usuario comprenda y colabore en la protección de su información personal. Entre las principales responsabilidades se encuentran:
          </p>
          <ul class="policy-list" id="user-responsibilities-list">
            <li class="policy-list-item">Proporcionar datos reales y actualizados al registrarse o solicitar nuestros servicios.</li>
            <li class="policy-list-item">Notificar inmediatamente a Andes Game Studio C.A. en caso de detectar algún uso indebido de sus datos personales o en caso de sufrir una violación de seguridad.</li>
            <li class="policy-list-item">Configurar adecuadamente las opciones de privacidad en los dispositivos y navegadores utilizados para acceder a nuestros servicios.</li>
            <li class="policy-list-item">Revisar y actualizar periódicamente sus datos personales para garantizar que la información almacenada sea precisa y confiable.</li>
          </ul>
          <p class="policy-paragraph" id="user-responsibilities-note">
            Al utilizar nuestros servicios, usted asume la responsabilidad de garantizar que la información proporcionada sea correcta y se compromete a notificar cualquier eventualidad que comprometa la seguridad y confidencialidad de sus datos.
          </p>

          <h2 class="policy-title" id="section-legal-disclaimer">Aviso Legal y Exoneración de Responsabilidad</h2>
          <p class="policy-paragraph" id="legal-disclaimer-text">
            Andes Game Studio C.A. se esfuerza por garantizar la seguridad de la información personal suministrada, sin embargo, no podemos garantizar la ausencia total de riesgos en el tratamiento y transmisión de datos a través de Internet. El usuario entiende y acepta que, pese a los esfuerzos y medidas de seguridad implementadas, la transmisión de datos a través de la red no puede ser completamente segura. En ningún caso Andes Game Studio C.A. será responsable por daños directos o indirectos que pudieran derivarse de un acceso no autorizado, pérdida, alteración o mal uso de la información personal.
          </p>

          <h2 class="policy-title" id="section-contact">Contacto e Información Adicional</h2>
          <p class="policy-paragraph" id="contact-text">
            En caso de que tenga preguntas, comentarios o inquietudes respecto a esta Política de Privacidad, o si desea ejercer sus derechos de acceso, rectificación y eliminación de datos, puede comunicarse con nosotros a través de los siguientes medios:
          </p>
          <ul class="policy-list" id="contact-methods">
            <li class="policy-list-item">Teléfono: +58 (212) 993-2140
              +58 (424) 212-8326</li>
            <li class="policy-list-item">Correo electrónico: studio_c.a._order@protonmail.com</li>
            <li class="policy-list-item">Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</li>
          </ul>
          <p class="policy-paragraph" id="contact-note">
            Nos comprometemos a responder a todas las solicitudes y consultas en el menor tiempo posible, y a brindar toda la asistencia necesaria para garantizar la protección de su información personal.
          </p>

          <h2 class="policy-title" id="section-conclusion">Conclusión</h2>
          <p class="policy-paragraph" id="conclusion-text">
            En resumen, esta Política de Privacidad establece de manera clara y detallada cómo Andes Game Studio C.A. recopila, utiliza, protege y, en su caso, comparte la información personal de sus usuarios, siempre en conformidad con la legislación vigente en Venezuela. Agradecemos su confianza y nos comprometemos a continuar esforzándonos por mejorar la seguridad y la calidad de nuestros servicios. Le recomendamos que guarde una copia de este documento para futuras consultas y se mantenga informado acerca de cualquier modificación que pueda surgir en relación con el tratamiento de sus datos.
          </p>
          <p class="policy-paragraph" id="final-note">
            Fecha de actualización: 2025-07-15. Al utilizar nuestro sitio y servicios, usted reconoce haber leído, comprendido y aceptado las condiciones expuestas en esta política, lo cual constituye un compromiso mutuo en el manejo responsable y seguro de la información personal.
          </p>
        </div>
      </div>

    </div>
  </main>

  <!-- Footer Section -->
  <footer class="footer-section bg-dark-blue-gray text-white py-5" id='contact-form'>
    <div class="container text-center">
      <a class="footer-logo-link" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="mb-3" style="height: 50px;">
        <span class="fw-bold text-steel-white">Andes Game Studio</span>
      </a>
      <p class="mb-3 text-white-50">Andes Game Studio C.A. – Desarrollo de videojuegos móviles (iOS & Android)</p>
      <p class="mb-2 text-white-50"><i class="bi bi-geo-alt-fill me-2 text-primary-custom"></i>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</p>
      <p class="mb-2 text-white-50"><i class="bi bi-phone-fill me-2 text-primary-custom"></i>Teléfono: <a href="tel:+58 (212) 993-2140" class="text-white-50 text-decoration-none">+58 (212) 993-2140
        </a> | <a href="tel:+58 (424) 212-8326" class="text-white-50 text-decoration-none">+58 (424) 212-8326</a></p>
      <p class="mb-3 text-white-50"><i class="bi bi-envelope-fill me-2 text-primary-custom"></i>Email: <a href="mailto:studio_c.a._order@protonmail.com" class="text-white-50 text-decoration-none">studio_c.a._order@protonmail.com</a></p>

      <div class="social-icons mb-4">
        <a href="https://www.facebook.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-facebook fs-4"></i>
        </a>
        <a href="https://x.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-twitter-x fs-4"></i>
        </a>
        <a href="https://www.linkedin.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-linkedin fs-4"></i>
        </a>

      </div>

      <ul class="list-inline footer-links mb-4">
        <li class="list-inline-item"><a href="privacy-info.php" class="text-white-50 text-decoration-none">Política de Privacidad</a></li>
        <li class="list-inline-item"><a href="terms-of-service.php" class="text-white-50 text-decoration-none">Términos y Condiciones</a></li>
        <li class="list-inline-item"><a href="liability-disclaimer.php" class="text-white-50 text-decoration-none">Descargo de Responsabilidad</a></li>
        <li class="list-inline-item"><a href="cookie-preferences.php" class="text-white-50 text-decoration-none">Política de Cookies</a></li>
      </ul>

      <p class="mb-0 text-white-50">&copy; 2025 Andes Game Studio C.A. Todos los derechos reservados.</p>
    </div>
  </footer>

  <!-- Cookie Consent Modal -->
  <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content bg-white border-0 shadow-lg">
        <div class="modal-header border-0 pb-0">
          <h5 class="modal-title fw-bold text-steel-blue" id="cookieConsentModalLabel">Configuración de Cookies</h5>
        </div>
        <div class="modal-body p-4">
          <p class="text-secondary">Utilizamos cookies para mejorar tu experiencia de navegación, personalizar contenido y analizar nuestro tráfico. Al hacer clic en "Aceptar todo", aceptas el uso de todas las cookies. Puedes personalizar tus preferencias a continuación.</p>
          <p class="text-secondary small">Consulta nuestra <a href="cookie-preferences.php" class="text-primary-custom fw-bold">Política de Cookies</a> para más información.</p>

          <div id="cookieCategories" class="mt-3">
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="mandatoryCookies" checked disabled>
              <label class="form-check-label text-steel-blue fw-bold" for="mandatoryCookies">
                Obligatorias <span class="text-secondary">(Siempre activas)</span>
              </label>
              <p class="text-secondary small ms-4">Necesarias para el funcionamiento básico del sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="analyticsCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="analyticsCookies">
                Analíticas
              </label>
              <p class="text-secondary small ms-4">Nos ayudan a entender cómo los visitantes interactúan con el sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="marketingCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="marketingCookies">
                Marketing
              </label>
              <p class="text-secondary small ms-4">Utilizadas para mostrar anuncios relevantes basados en tus intereses.</p>
            </div>
          </div>

          <div class="d-flex justify-content-between mt-4">
            <button type="button" class="btn btn-outline-secondary" id="declineCookies">Rechazar</button>
            <button type="button" class="btn btn-primary-custom" id="acceptAllCookies">Aceptar Todo</button>
          </div>
          <div class="d-grid mt-3">
            <button type="button" class="btn btn-link text-primary-custom fw-bold" id="saveCookieSelection">Guardar Selección</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Popper.js (Required for Bootstrap JS) -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <!-- Bootstrap 5 JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
  <!-- Custom JavaScript -->
  <script src="frontend/script.js"></script>
</body>

</html>