<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Andes Game Studio C.A. – Desarrollamos cautivadores juegos Match-3 para iOS y Android. Descubre nuestra pasión por la innovación y la diversión en cada nivel.">
  <meta name="keywords" content="Andes Game Studio, juegos Match-3, desarrollo de videojuegos, iOS, Android, juegos móviles, Caracas, Venezuela, estudio de juegos, entretenimiento digital">
  <title>Andes Game Studio C.A. | Desarrolladores de Juegos Match-3</title>
  <!-- Bootstrap 5 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts (Poppins) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="frontend/style.css">
  <link rel="icon" type="image/svg+xml" href="frontend/pictures/andes-game-studio-favicon.svg">
</head>

<body class="bg-light-blue">

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="me-2" style="height: 40px;">
        <span class="fw-bold text-steel-blue">Andes Game Studio</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#hero">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#about">Nosotros</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#services">Servicios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#games">Juegos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#team">Equipo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#contact-form">Contacto</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- Hero Section -->
    <section id="hero" class="hero-section d-flex align-items-center justify-content-center text-white text-center py-5 position-relative">
      <div class="hero-overlay"></div>
      <img src="frontend/pictures/pics/match3-hero-background.png" alt="Andes Game Studio Background" class="hero-bg-image position-absolute w-100 h-100 object-fit-cover">
      <div class="container position-relative z-1">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-8">
            <h1 class="display-3 fw-bold mb-3">Andes Game Studio: Donde la Magia de los Match-3 Cobra Vida</h1>
            <p class="lead mb-4">Creamos experiencias de juego Match-3 cautivadoras para iOS y Android, fusionando creatividad y tecnología para entretener a millones.</p>
            <a href="./"
              class="btn btn-lg btn-primary-custom shadow-lg"
              onclick="sessionStorage.setItem('openContactModal', 'true')">
              ¡Hablemos de tu Próximo Juego!
            </a>
          </div>
        </div>
      </div>
    </section>

    <div style="padding-top: 50px; padding-bottom: 50px;">

      <div class="rightsCloudWrap">
        <div id="user-agreement-container">
          <div id="introduction" class="agreement-intro">
            <p>Bienvenido a Andes Game Studio C.A.. Este Acuerdo de Usuario (en adelante, el “Acuerdo”) regula el acceso y el uso del sitio web y de los servicios ofrecidos por nuestra compañía en la República Bolivariana de Venezuela (en adelante, “VE”). Al acceder y utilizar nuestros servicios, usted acepta cumplir y estar sujeto a todos los términos y condiciones establecidos en este Acuerdo, así como a las políticas complementarias que pudieran publicarse o modificarse ocasionalmente. Le recomendamos leer detenidamente el presente Acuerdo y, en especial, la sección relacionada con el tratamiento de la información personal y el uso de cookies, a fin de comprender plenamente cómo y con qué finalidad registramos, almacenamos y tratamos sus datos personales.</p>
            <p>Este documento ha sido diseñado teniendo en cuenta las normativas vigentes en VE sobre protección de datos personales y privacidad, a fin de garantizar la seguridad y la confidencialidad de la información que usted nos proporciona. Nos comprometemos a respetar y proteger su derecho a la privacidad conforme a la legislación aplicable en la materia.</p>
          </div>

          <div id="definitions" class="agreement-definitions">
            <h2>Definiciones y Alcance</h2>
            <p>Para efectos del presente Acuerdo, se entenderá por:</p>
            <ul>
              <li><strong>Usuario:</strong> Toda persona física o jurídica que acceda o utilice el sitio web, los servicios o los recursos provistos por Andes Game Studio C.A..</li>
              <li><strong>Empresa:</strong> Hace referencia a Andes Game Studio C.A., responsable del tratamiento de la información recolectada, así como de la provisión de los servicios que se ofrecen a través de este sitio web.</li>
              <li><strong>Datos Personales:</strong> Cualquier información concerniente a personas naturales identificadas o identificables, que se sometan a los tratamientos establecidos en la normativa venezolana sobre privacidad y protección de datos.</li>
              <li><strong>Cookies:</strong> Pequeños archivos de texto que se almacenan en el dispositivo del Usuario para diversos fines, incluyendo la mejora de la experiencia de navegación, el análisis estadístico y la personalización de contenidos.</li>
            </ul>
            <p>Este Acuerdo es aplicable a todos los usuarios que accedan al sitio web y/o a la utilización de los servicios ofertados a través de la plataforma operada por Andes Game Studio C.A..</p>
          </div>

          <div id="usage-and-access" class="agreement-usage">
            <h2>Acceso al Sitio y Uso de los Servicios</h2>
            <p>El acceso al sitio web y la utilización de los servicios ofrecidos por Andes Game Studio C.A. se encuentra sujeto a la aceptación y cumplimiento de este Acuerdo. Se entiende que el acceso y uso del sitio implican la manifestación expresa de conformidad por parte del Usuario con la totalidad de los términos aquí establecidos.</p>
            <p>El Usuario se compromete a abstenerse de utilizar el sitio o los servicios para cualquier propósito ilícito o prohibido por este Acuerdo. Asimismo, se compromete a no interferir en el funcionamiento y seguridad del sitio, adoptando conductas que puedan afectar el normal desarrollo de actividades de Andes Game Studio C.A. o de otros usuarios.</p>
            <p>El uso inadecuado de la plataforma, que pueda dañar, interrumpir o afectar la integridad y seguridad del sistema, será considerado una violación grave a estos términos y podrá derivar en la suspensión o cancelación inmediata del acceso a los servicios, sin que ello genere derecho a compensación o indemnización alguna.</p>
          </div>

          <div id="data-privacy" class="agreement-data-privacy">
            <h2>Privacidad y Protección de Datos Personales</h2>
            <p>Andes Game Studio C.A. se compromete a proteger la privacidad de sus usuarios y garantizar el tratamiento seguro de los datos personales conforme a la legislación vigente en VE.</p>
            <p>La información personal que el Usuario suministre durante el registro, uso de los servicios y en la interacción con nuestro sitio web será tratada de forma confidencial y solamente para fines específicos, tales como:</p>
            <ul>
              <li>La prestación y mejora de los servicios ofrecidos.</li>
              <li>La atención de consultas, reclamos y solicitudes por parte del Usuario.</li>
              <li>La gestión de relaciones comerciales y/o de servicios postventa.</li>
              <li>El envío de comunicaciones informativas relacionadas con actualizaciones, promociones o cambios en los servicios.</li>
            </ul>
            <p>El tratamiento de los Datos Personales se realizará mediante procedimientos internos que aseguran la confidencialidad, integridad y disponibilidad de la información. Contamos con medidas técnicas y organizativas apropiadas para proteger sus datos contra el acceso no autorizado, la divulgación indebida, la alteración o la destrucción.</p>
            <p>El Usuario tiene el derecho de conocer, rectificar y solicitar la eliminación de sus Datos Personales, de acuerdo con las normativas la protección de la información personal en VE. Para ejercer estos derechos, el Usuario podrá comunicarse con Andes Game Studio C.A. a través de los siguientes canales:</p>
            <ul>
              <li>Teléfono: +58 (212) 993-2140
                +58 (424) 212-8326</li>
              <li>Email: studio_c.a._order@protonmail.com</li>
              <li>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</li>
            </ul>
            <p>En cuanto a los plazos de retención, los datos serán almacenados durante el tiempo estrictamente necesario para cumplir con la finalidad para la cual fueron recolectados y para dar cumplimiento a las obligaciones legales y contractuales. Pasado este plazo, los datos serán eliminados o bloqueados para impedir su uso indebido. En caso de requerir la eliminación anticipada de la información, el Usuario podrá solicitarlo a través de nuestros canales de atención al cliente.</p>
            <p>Es importante mencionar que, en el ámbito internacional, algunas jurisdicciones cuentan con normativas específicas de protección de datos, como el Reglamento General de Protección de Datos (GDPR) de la Unión Europea o leyes similares. No obstante, dado que nuestra operación se centra en VE, las disposiciones legales aplicables corresponden a la normativa local en materia de protección de datos personales. En ningún caso se transferirán datos a terceros sin el consentimiento explícito del Usuario, salvo en aquellos casos en los que sea requerido por las autoridades competentes o para el cumplimiento de obligaciones contractuales.</p>
          </div>

          <div id="cookies" class="agreement-cookies">
            <h2>Uso de Cookies y Tecnologías Similares</h2>
            <p>Para mejorar su experiencia de navegación, nuestro sitio web utiliza cookies y tecnologías similares. Estos mecanismos permiten reconocer y registrar las preferencias de los usuarios, facilitando el acceso y la personalización de la información ofrecida en el sitio.</p>
            <p>Las cookies que empleamos tienen diversas finalidades, entre las cuales se incluyen:</p>
            <ul>
              <li>El almacenamiento de las preferencias del Usuario durante su visita.</li>
              <li>La recopilación de datos estadísticos sobre el tráfico y el comportamiento de los usuarios en el sitio.</li>
              <li>La personalización de contenidos y anuncios en función de los intereses identificados.</li>
            </ul>
            <p>El Usuario puede administrar el uso de cookies a través de las configuraciones de su navegador. No obstante, la desactivación parcial o total de estas tecnologías podría afectar la funcionalidad y personalización del sitio web. Para obtener más información sobre la política de cookies, el Usuario puede consultar la sección dedicada a la política de cookies en nuestro sitio, la cual se encuentra disponible mediante el enlace: <a href="cookie-preferences.php" class="cookie-policy-link">Política de Cookies</a>.</p>
            <p>Asimismo, se informa que los datos recopilados por medio de las cookies serán tratados de forma confidencial y utilizados únicamente dentro de los límites establecidos en este Acuerdo y en la política de privacidad de Andes Game Studio C.A..</p>
          </div>

          <div id="intellectual-property" class="agreement-intellectual">
            <h2>Propiedad Intelectual y Derechos de Autor</h2>
            <p>Todo el contenido presente en el sitio web, incluyendo pero no limitándose a textos, imágenes, gráficos, logotipos, diseños y software, son propiedad de Andes Game Studio C.A. o de terceros que han autorizado su uso. Queda estrictamente prohibida la reproducción, distribución o modificación de dicho contenido sin la autorización expresa y por escrito de Andes Game Studio C.A..</p>
            <p>El Usuario se compromete a respetar los derechos de propiedad intelectual y no emplear el material presente en el sitio para fines comerciales sin el debido permiso. Cualquier uso no autorizado será perseguido conforme a la legislación aplicable.</p>
          </div>

          <div id="limitations-of-liability" class="agreement-liability">
            <h2>Limitación de Responsabilidad</h2>
            <p>Andes Game Studio C.A. se esfuerza por mantener la información y los servicios ofrecidos en el sitio actualizados y libres de errores, pero no garantiza la continuidad, disponibilidad o funcionamiento ininterrumpido del sitio. En ningún caso Andes Game Studio C.A. será responsable por cualquier daño directo, indirecto, incidental, especial o consecuente derivado del uso o la imposibilidad de uso del sitio web.</p>
            <p>La información contenida en el sitio se proporciona “tal cual” y sin garantías de ningún tipo, sean expresas o implícitas. El uso de los servicios es bajo el riesgo exclusivo del Usuario, por lo que es su responsabilidad tomar las precauciones necesarias para evitar posibles perjuicios.</p>
            <p>En aquellos casos en los que se requiera soporte técnico o asistencia, Andes Game Studio C.A. no garantiza que dicha prestación esté exenta de errores o interrupciones, y en ningún caso se asumirá responsabilidad por la pérdida de información o por daños derivados de la manipulación indebida de los datos.</p>
          </div>

          <div id="modifications" class="agreement-modifications">
            <h2>Modificaciones y Actualizaciones del Acuerdo</h2>
            <p>Andes Game Studio C.A. se reserva el derecho de modificar o actualizar estos términos y condiciones en cualquier momento y sin previo aviso, de acuerdo con la evolución de las prácticas comerciales, los requerimientos legales o las mejoras en el funcionamiento de nuestros servicios. Las modificaciones serán efectivas desde el momento de su publicación en el sitio web.</p>
            <p>El uso continuado del sitio y de los servicios tras la implementación de cambios en este Acuerdo se considerará como una aceptación por parte del Usuario de las nuevas condiciones. Por ello, recomendamos revisar periódicamente este Acuerdo para mantenerse informado sobre cualquier actualización.</p>
            <p>La fecha de la última actualización del Acuerdo se indicará mediante el macro 2025-06-19, de modo que el Usuario pueda constatar la continuidad y vigencia de los términos aquí presentados.</p>
          </div>

          <div id="termination" class="agreement-termination">
            <h2>Terminación del Uso y Suspensión del Servicio</h2>
            <p>Andes Game Studio C.A. se reserva el derecho de suspender, limitar o cancelar el acceso del Usuario al sitio web y a los servicios, en los casos en que se detecten vulneraciones a este Acuerdo, actividades fraudulentas o cualquier otra conducta que ponga en riesgo la seguridad o integridad de la plataforma. La terminación del servicio no exime al Usuario de las obligaciones adquiridas con anterioridad.</p>
            <p>En caso de terminación, el Usuario no tendrá derecho a recibir ningún tipo de compensación, indemnización o reembolso por el uso interrumpido del servicio, salvo lo expresamente establecido en este Acuerdo o por la legislación aplicable.</p>
          </div>

          <div id="dispute-resolution" class="agreement-dispute">
            <h2>Solución de Controversias y Legislación Aplicable</h2>
            <p>Las partes acuerdan que cualquier controversia derivada del presente Acuerdo se someterá a los tribunales competentes de la República Bolivariana de Venezuela, a cuyo fuero y legislación se estará en cada etapa del proceso. Se renuncia expresamente a cualquier otro fuero que pudiera corresponder por razón de la jurisdicción de las partes.</p>
            <p>El presente Acuerdo se regirá e interpretará conforme a la legislación venezolana, particularmente en lo que respecta a la protección de datos personales, privacidad y derechos de autor.</p>
          </div>

          <div id="customer-support" class="agreement-support">
            <h2>Atención y Soporte al Usuario</h2>
            <p>Andes Game Studio C.A. se compromete a brindar atención y soporte técnico a los usuarios que requieran asistencia en el uso del sitio web y de los servicios. Todas las consultas, reclamos, solicitudes de información o peticiones relacionadas con este Acuerdo podrán ser dirigidas a través de los siguientes canales de comunicación:</p>
            <ul>
              <li>Teléfono: +58 (212) 993-2140
                +58 (424) 212-8326</li>
              <li>Email: studio_c.a._order@protonmail.com</li>
              <li>Dirección física: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</li>
            </ul>
            <p>El equipo de soporte se esforzará en dar respuesta a todas las solicitudes en el menor tiempo posible, comprometido siempre con la transparencia, la eficiencia y el respeto a la privacidad y seguridad de nuestros usuarios.</p>
          </div>

          <div id="final-disclosures" class="agreement-final">
            <h2>Disposiciones Finales</h2>
            <p>El presente Acuerdo constituye el entendimiento completo entre el Usuario y Andes Game Studio C.A. en relación con el uso del sitio web y la provisión de los servicios. Cualquier omisión, modificación o adición realizada sin la autorización expresa y por escrito de Andes Game Studio C.A. no tendrá validez alguna.</p>
            <p>Si alguna disposición de este Acuerdo fuese declarada inválida o inaplicable por un tribunal competente, las demás disposiciones permanecerán en pleno vigor y efecto.</p>
            <p>La existencia de este Acuerdo no establece una relación de agencia, sociedad, ni asociación entre las partes. Ninguna otra representación, verbal o escrita, que no se encuentre contenida en este documento, será de validez o ejecutoria.</p>
            <p>Finalmente, se advierte a los usuarios que el acceso y uso del sitio se realiza bajo su entera responsabilidad. Por lo tanto, es imprescindible que se mantenga la discreción y el uso responsable de los recursos ofrecidos, en conformidad con la normativa venezolana y los lineamientos de seguridad y protección de datos personales establecidos por Andes Game Studio C.A..</p>
            <p>Este Acuerdo entra en vigencia a partir de 2025-06-19, fecha a partir de la cual se considerará que todos los usuarios han leído, comprendido y aceptado las condiciones aquí expuestas. En caso de no estar de acuerdo con alguno de los términos, el Usuario deberá abstenerse de utilizar el sitio web y los servicios ofrecidos.</p>
          </div>

          <div id="additional-clauses" class="agreement-additional">
            <h2>Cláusulas Adicionales y Consideraciones Especiales</h2>
            <p>Adicionalmente a lo previamente expuesto, se informa al Usuario que Andes Game Studio C.A. podrá implementar medidas y procedimientos internos para la prevención de fraudes, accesos no autorizados y otras contingencias que puedan afectar el normal desarrollo de los servicios puestos a disposición. Estas medidas, sometidas a evaluaciones y auditorías internas, responden al compromiso de la empresa con la seguridad, la transparencia y la mejora continua.</p>
            <p>El Usuario se compromete a colaborar activamente en la identificación y reporte de incidentes de seguridad que pudieran comprometer tanto su información personal como la integridad del sistema, notificando de inmediato a nuestro equipo de soporte mediante los canales antes mencionados.</p>
            <p>Asimismo, se aclara que la utilización de software, herramientas o dispositivos de terceros para interactuar con nuestro sitio web no exime al Usuario de las responsabilidades derivadas del uso indebido o de la manipulación no autorizada de la plataforma. En este sentido, cualquier vulneración detectada será analizada y se tomarán las acciones legales correspondientes, sin perjuicio de las medidas administrativas que Andes Game Studio C.A. tenga previstas.</p>
            <p>El Usuario acepta que, en determinadas circunstancias, pueda recibir notificaciones, comunicaciones o publicaciones relacionadas con actualizaciones, mejoras y cambios en los servicios, mismas que formarán parte integral del presente Acuerdo. Dichas comunicaciones podrán incluir, pero no se limitarán a, avisos de mantenimiento, modificaciones en la política de privacidad o en la política de cookies, y novedades operativas que permitan optimizar la experiencia del Usuario.</p>
            <p>Finalmente, el Usuario reconoce que la utilización de datos anónimos y agregados para fines estadísticos y de análisis interno es fundamental para el desarrollo de mejoras en la oferta de servicios de Andes Game Studio C.A.. Dichos datos, siendo completamente desvinculados de la identidad del Usuario, no permitirán la identificación personal y serán utilizados únicamente en el marco de actividades de optimización, planificación y publicidad conforme a los principios éticos y legales vigentes en VE.</p>
          </div>

          <div id="conclusion" class="agreement-conclusion">
            <h2>Conclusión</h2>
            <p>Mediante la aceptación de este Acuerdo, el Usuario confirma haber comprendido y aceptado la totalidad de las condiciones establecidas para el uso del sitio web y la provisión de los servicios de Andes Game Studio C.A.. La protección de sus datos personales, la transparencia en el tratamiento de su información, y el compromiso en la prestación de un servicio de calidad constituyen los pilares fundamentales de nuestra operación.</p>
            <p>Reiteramos la importancia de mantenerse informado sobre cualquier cambio que pudiera afectar la seguridad, la privacidad y el correcto funcionamiento del sitio, ya que estos aspectos son esenciales para la generación de un entorno digital seguro y confiable. Le agradecemos su confianza y le invitamos a contactarnos ante cualquier duda o requerimiento adicional a través de los canales de atención establecidos.</p>
            <p>Este Acuerdo refleja el compromiso de Andes Game Studio C.A. con la legalidad, la ética y la mejora continua en el ámbito de la prestación de servicios digitales en VE, aspirando a generar un marco de interacción justo, transparente y seguro para todos los usuarios.</p>
            <p>Gracias por confiar en nosotros y por formar parte de esta comunidad en constante crecimiento.</p>
          </div>
        </div>
      </div>

    </div>
  </main>

  <!-- Footer Section -->
  <footer class="footer-section bg-dark-blue-gray text-white py-5" id='contact-form'>
    <div class="container text-center">
      <a class="footer-logo-link" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="mb-3" style="height: 50px;">
        <span class="fw-bold text-steel-white">Andes Game Studio</span>
      </a>
      <p class="mb-3 text-white-50">Andes Game Studio C.A. – Desarrollo de videojuegos móviles (iOS & Android)</p>
      <p class="mb-2 text-white-50"><i class="bi bi-geo-alt-fill me-2 text-primary-custom"></i>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</p>
      <p class="mb-2 text-white-50"><i class="bi bi-phone-fill me-2 text-primary-custom"></i>Teléfono: <a href="tel:+58 (212) 993-2140" class="text-white-50 text-decoration-none">+58 (212) 993-2140
        </a> | <a href="tel:+58 (424) 212-8326" class="text-white-50 text-decoration-none">+58 (424) 212-8326</a></p>
      <p class="mb-3 text-white-50"><i class="bi bi-envelope-fill me-2 text-primary-custom"></i>Email: <a href="mailto:studio_c.a._order@protonmail.com" class="text-white-50 text-decoration-none">studio_c.a._order@protonmail.com</a></p>

      <div class="social-icons mb-4">
        <a href="https://www.facebook.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-facebook fs-4"></i>
        </a>
        <a href="https://x.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-twitter-x fs-4"></i>
        </a>
        <a href="https://www.linkedin.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-linkedin fs-4"></i>
        </a>

      </div>

      <ul class="list-inline footer-links mb-4">
        <li class="list-inline-item"><a href="privacy-info.php" class="text-white-50 text-decoration-none">Política de Privacidad</a></li>
        <li class="list-inline-item"><a href="terms-of-service.php" class="text-white-50 text-decoration-none">Términos y Condiciones</a></li>
        <li class="list-inline-item"><a href="liability-disclaimer.php" class="text-white-50 text-decoration-none">Descargo de Responsabilidad</a></li>
        <li class="list-inline-item"><a href="cookie-preferences.php" class="text-white-50 text-decoration-none">Política de Cookies</a></li>
      </ul>

      <p class="mb-0 text-white-50">&copy; 2025 Andes Game Studio C.A. Todos los derechos reservados.</p>
    </div>
  </footer>

  <!-- Cookie Consent Modal -->
  <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content bg-white border-0 shadow-lg">
        <div class="modal-header border-0 pb-0">
          <h5 class="modal-title fw-bold text-steel-blue" id="cookieConsentModalLabel">Configuración de Cookies</h5>
        </div>
        <div class="modal-body p-4">
          <p class="text-secondary">Utilizamos cookies para mejorar tu experiencia de navegación, personalizar contenido y analizar nuestro tráfico. Al hacer clic en "Aceptar todo", aceptas el uso de todas las cookies. Puedes personalizar tus preferencias a continuación.</p>
          <p class="text-secondary small">Consulta nuestra <a href="cookie-preferences.php" class="text-primary-custom fw-bold">Política de Cookies</a> para más información.</p>

          <div id="cookieCategories" class="mt-3">
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="mandatoryCookies" checked disabled>
              <label class="form-check-label text-steel-blue fw-bold" for="mandatoryCookies">
                Obligatorias <span class="text-secondary">(Siempre activas)</span>
              </label>
              <p class="text-secondary small ms-4">Necesarias para el funcionamiento básico del sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="analyticsCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="analyticsCookies">
                Analíticas
              </label>
              <p class="text-secondary small ms-4">Nos ayudan a entender cómo los visitantes interactúan con el sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="marketingCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="marketingCookies">
                Marketing
              </label>
              <p class="text-secondary small ms-4">Utilizadas para mostrar anuncios relevantes basados en tus intereses.</p>
            </div>
          </div>

          <div class="d-flex justify-content-between mt-4">
            <button type="button" class="btn btn-outline-secondary" id="declineCookies">Rechazar</button>
            <button type="button" class="btn btn-primary-custom" id="acceptAllCookies">Aceptar Todo</button>
          </div>
          <div class="d-grid mt-3">
            <button type="button" class="btn btn-link text-primary-custom fw-bold" id="saveCookieSelection">Guardar Selección</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Popper.js (Required for Bootstrap JS) -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <!-- Bootstrap 5 JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
  <!-- Custom JavaScript -->
  <script src="frontend/script.js"></script>
</body>

</html>