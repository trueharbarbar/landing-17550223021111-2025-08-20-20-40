<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Andes Game Studio C.A. – Desarrollamos cautivadores juegos Match-3 para iOS y Android. Descubre nuestra pasión por la innovación y la diversión en cada nivel.">
  <meta name="keywords" content="Andes Game Studio, juegos Match-3, desarrollo de videojuegos, iOS, Android, juegos móviles, Caracas, Venezuela, estudio de juegos, entretenimiento digital">
  <title>Andes Game Studio C.A. | Desarrolladores de Juegos Match-3</title>
  <!-- Bootstrap 5 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts (Poppins) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="frontend/style.css">
  <link rel="icon" type="image/svg+xml" href="frontend/pictures/andes-game-studio-favicon.svg">
</head>

<body class="bg-light-blue">

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="me-2" style="height: 40px;">
        <span class="fw-bold text-steel-blue">Andes Game Studio</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#hero">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#about">Nosotros</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#services">Servicios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#games">Juegos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#team">Equipo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-steel-blue" href="index.php#contact-form">Contacto</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- Hero Section -->
    <section id="hero" class="hero-section d-flex align-items-center justify-content-center text-white text-center py-5 position-relative">
      <div class="hero-overlay"></div>
      <img src="frontend/pictures/pics/match3-hero-background.png" alt="Andes Game Studio Background" class="hero-bg-image position-absolute w-100 h-100 object-fit-cover">
      <div class="container position-relative z-1">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-8">
            <h1 class="display-3 fw-bold mb-3">Andes Game Studio: Donde la Magia de los Match-3 Cobra Vida</h1>
            <p class="lead mb-4">Creamos experiencias de juego Match-3 cautivadoras para iOS y Android, fusionando creatividad y tecnología para entretener a millones.</p>
            <a href="./"
              class="btn btn-lg btn-primary-custom shadow-lg"
              onclick="sessionStorage.setItem('openContactModal', 'true')">
              ¡Hablemos de tu Próximo Juego!
            </a>
          </div>
        </div>
      </div>
    </section>

    <div style="padding-top: 50px; padding-bottom: 50px;">

      <div class="rightsCloudWrap">
        <div id="cookie-policy-container" class="policy-container">
          <div id="introduction" class="policy-section-wrap">
            <h2 class="section-box-title">Introducción y Alcance</h2>
            <p class="section-block-paragraph">
              Bienvenido a la política de uso de cookies de Andes Game Studio C.A.. En este documento se describe de manera detallada la manera en que esta plataforma, que ofrece servicios especializados, utiliza cookies y tecnologías similares para mejorar la experiencia del usuario, facilitar la navegación, y personalizar el contenido ofrecido. El presente texto se desarrolla cumpliendo con la normativa vigente en materia de protección de datos personales y privacidad, así como con las recomendaciones aplicables en general para este tipo de servicios digitales. A lo largo del contenido se explican las distintas categorías de cookies utilizadas, la finalidad de cada una de ellas, y los derechos de los usuarios en relación a la gestión y eliminación de la información. La política se aplica a todos los usuarios que accedan a nuestro sitio, y se actualiza periódicamente para adaptarse tanto a la evolución tecnológica como a las exigencias legales.
            </p>
            <p class="section-wrap-paragraph">
              Es de suma importancia que el usuario lea detenidamente este documento, ya que al navegar y utilizar nuestros servicios, acepta de manera implícita el uso de cookies conforme a lo que se expone en la presente política. Nos comprometemos a mantener un alto nivel de transparencia y seguridad en el manejo de los datos que se recogen, almacenan y procesan a través de las cookies, con el fin de proteger la privacidad y los derechos fundamentales de las personas.
            </p>
          </div>

          <div id="what-are-cookies" class="policy-section-block">
            <h2 class="section-wrap-title">¿Qué son las Cookies y para qué se utilizan?</h2>
            <p class="section-block-paragraph">
              Las cookies son pequeños archivos de texto que se almacenan en el dispositivo del usuario cada vez que visita un sitio web. Estas herramientas permiten que el sitio recuerde información sobre la visita, lo que contribuye a mejorar la experiencia de navegación en futuras visitas. Entre las principales funciones se encuentran:
            </p>
            <ul class="list-items">
              <li class="list-item">Facilitar la navegación y evitar la repetición de autentificaciones o preferencias.</li>
              <li class="list-item">Guardar configuraciones de idioma, ubicación y personalización del contenido.</li>
              <li class="list-item">Permitir la realización de análisis sobre el comportamiento del usuario en el sitio, para optimizar progresivamente los servicios ofrecidos.</li>
              <li class="list-item">Ofrecer contenido y publicidad personalizada respetando la privacidad e integridad de la información del usuario.</li>
            </ul>
            <p class="section-wrap-paragraph">
              Estas cookies pueden clasificarse en dos grandes categorías: cookies de sesión, que se utilizan durante la visita y se eliminan automáticamente al cerrar el navegador; y cookies persistentes, que permanecen en el dispositivo del usuario durante un periodo determinado o hasta que se eliminan manualmente. Además, existen cookies propias (instaladas por Andes Game Studio C.A.) y de terceros (instaladas por colaboradores o socios que nos ayudan a analizar el tráfico o mostrar publicidad).
            </p>
          </div>

          <div id="cookie-types" class="policy-section-container">
            <h2 class="section-wrap-title">Tipos de Cookies y su Uso Específico</h2>
            <p class="section-wrap-paragraph">
              En Andes Game Studio C.A., se utilizan las siguientes categorías de cookies:
            </p>
            <h3 class="subsection-title">1. Cookies Esenciales</h3>
            <p class="section-wrap-paragraph">
              Estas cookies son imprescindibles para el funcionamiento correcto de la página. Permiten, por ejemplo, la navegación por la web y el acceso a áreas seguras sin tener que volver a autenticar al usuario. Sin ellas, el servicio no podría brindar funciones básicas, por lo que su desactivación podría afectar gravemente la experiencia de uso.
            </p>
            <h3 class="subsection-title">2. Cookies de Rendimiento y Analíticas</h3>
            <p class="section-box-paragraph">
              Estas cookies se utilizan para recoger datos de forma anónima sobre el uso y el rendimiento del sitio. La información recopilada se analiza para entender el comportamiento del usuario y, de esta forma, se optimiza la funcionalidad del servicio. Los datos se tratan de manera agregada, sin identificar a ningún usuario en particular, y se gestionan conforme a estrictos protocolos de seguridad.
            </p>
            <h3 class="subsection-title">3. Cookies de Funcionalidad</h3>
            <p class="section-container-paragraph">
              Permiten recordar elecciones realizadas por el usuario, como preferencia de idioma o configuraciones de visualización. Gracias a estas cookies, se facilita una experiencia personalizada que se adapta a las necesidades individuales durante futuras visitas.
            </p>
            <h3 class="subsection-title">4. Cookies de Publicidad y Marketing</h3>
            <p class="section-block-paragraph">
              Estas cookies permiten que el contenido publicitario se adapte a los intereses mostrados por el usuario y que se muestre de forma coherente en distintas plataformas. Se emplean también para limitar la cantidad de veces que se muestra un anuncio, mejorando la relevancia de la publicidad sin invadir la privacidad del usuario.
            </p>
          </div>

          <div id="cookie-management" class="policy-section-container">
            <h2 class="section-block-title">Gestión, Modificación y Eliminación de Cookies</h2>
            <p class="section-container-paragraph">
              El usuario tiene la capacidad de aceptar, modificar o rechazar el uso de cookies en cualquier momento. La mayoría de los navegadores permiten gestionar la configuración de cookies, desde su aceptación automática hasta la desactivación total. Si el usuario decide rechazar las cookies, puede experimentar una disminución en la funcionalidad del sitio o en la personalización de los servicios ofrecidos.
            </p>
            <p class="section-block-paragraph">
              Se recomienda revisar la sección de ajustes de privacidad del navegador o utilizar las herramientas que Andes Game Studio C.A. ha dispuesto para gestionar las preferencias de cookies. Esto puede incluir desde la desactivación de ciertas categorías hasta la eliminación completa de todas las cookies almacenadas en el dispositivo.
            </p>
            <p class="section-block-paragraph">
              Además, se informa que, en el caso de que el usuario decida solicitar la eliminación de datos relacionados con las cookies o realice una revocación de consentimiento, se atenderá dicha solicitud de acuerdo con los procedimientos internos establecidos, garantizando que la información se borre de forma segura y definitiva en un plazo razonable, conforme a lo estipulado en la ley aplicable.
            </p>
          </div>

          <div id="data-security" class="policy-section-wrap">
            <h2 class="section-container-title">Protección y Seguridad de los Datos</h2>
            <p class="section-box-paragraph">
              La seguridad de los datos es una prioridad esencial en Andes Game Studio C.A.. Para garantizar la protección contra accesos no autorizados, divulgación, alteración o destrucción incorrecta de la información, se han implementado las siguientes medidas:
            </p>
            <ul class="list-items">
              <li class="list-item">Utilización de protocolos de encriptación avanzados en la transmisión de datos.</li>
              <li class="list-item">Sistemas de detección y prevención de intrusiones en la red, monitorizados de manera constante.</li>
              <li class="list-item">Acceso restringido a la información únicamente al personal autorizado, mediante autenticación y control de accesos.</li>
              <li class="list-item">Realización de auditorías internas y externas para asegurar el cumplimiento de las normativas de protección de datos.</li>
            </ul>
            <p class="section-box-paragraph">
              Estas medidas se revisan periódicamente para asegurar su adecuación y observar el avance tecnológico, garantizando que la información bajo nuestra custodia esté protegida mediante los estándares más altos de seguridad.
            </p>
          </div>

          <div id="rights-of-users" class="policy-section-block">
            <h2 class="section-box-title">Derechos de los Usuarios y Solicitudes de Eliminación de Datos</h2>
            <p class="section-container-paragraph">
              Con el objetivo de ofrecer total transparencia en el manejo de sus datos, Andes Game Studio C.A. reconoce y respeta los derechos de cada usuario con respecto a la información personal recopilada a través de las cookies. Entre los derechos fundamentales se encuentran:
            </p>
            <ul class="list-items">
              <li class="list-item">El derecho a acceder a los datos personales que se hayan recogido y almacenado.</li>
              <li class="list-item">El derecho a solicitar la modificación o actualización de los datos si estos resultan ser inexactos o incompletos.</li>
              <li class="list-item">El derecho a solicitar la eliminación de los datos, en caso de que estos ya no sean necesarios para la finalidad recogida.</li>
              <li class="list-item">El derecho a retirar el consentimiento otorgado para el uso de cookies en cualquier momento, sin perjuicio de la legalidad del tratamiento basado en dicho consentimiento previo a su retiro.</li>
              <li class="list-item">El derecho a recibir información clara y precisa sobre el tratamiento de sus datos personales.</li>
            </ul>
            <p class="section-wrap-paragraph">
              Para ejercer estos derechos, el usuario podrá acudir a las herramientas proporcionadas en Andes Game Studio C.A. o bien, en su defecto, a los mecanismos de contacto que se hayan dispuesto para tales efectos. Todas las solicitudes serán atendidas en el plazo máximo permitido por la ley, y se informará al usuario de las acciones realizadas.
            </p>
          </div>

          <div id="data-retention" class="policy-section-container">
            <h2 class="section-container-title">Plazos de Retención de Datos</h2>
            <p class="section-box-paragraph">
              Los datos obtenidos a través de cookies se conservarán únicamente durante el tiempo necesario para cumplir con la finalidad para la cual fueron recogidos. En el caso de cookies esenciales, la información se retendrá durante la sesión activa del usuario. En el caso de cookies persistentes, se establecerá un periodo concreto de conservación, tras el cual dichos datos serán eliminados de manera automática o mediante acción manual del usuario.
            </p>
            <p class="section-container-paragraph">
              La estrategia de retención de datos se fundamenta en el principio de minimización, asegurando que ningún dato se guarde de forma prolongada sin una justificación válida. Cuando el usuario solicite la eliminación de sus datos, se ejecutará dicho proceso de forma inmediata, de acuerdo con los procedimientos internos que garantizan la seguridad y la integridad de la información.
            </p>
          </div>

          <div id="legal-compliance" class="policy-section-block">
            <h2 class="section-container-title">Cumplimiento Normativo y Referencias Legales</h2>
            <p class="section-container-paragraph">
              Andes Game Studio C.A. se adhiere a las normativas vigentes en materia de protección de datos personales y privacidad, garantizando que la utilización de cookies cumpla con los requerimientos legales aplicables. Todas las prácticas de recogida, almacenamiento y procesamiento de información se realizan en estricto apego a los principios de transparencia, lealtad y seguridad establecidos en la legislación correspondiente.
            </p>
            <p class="section-container-paragraph">
              Este documento ha sido elaborado considerando las disposiciones legales y requerimientos normativos de la entidad reguladora en materia de privacidad. Se implementan protocolos que aseguran el cumplimiento de los derechos de los usuarios, garantizando asimismo que se brinda la posibilidad de solicitar la modificación o eliminación de datos de manera ágil y segura.
            </p>
            <p class="section-container-paragraph">
              Aunque en algunas jurisdicciones existen normativas específicas como el Reglamento General de Protección de Datos (GDPR) o similares, en nuestro contexto se han adoptado prácticas recomendadas y estándares internacionales en materia de protección de la privacidad y seguridad de la información. Este enfoque permite que los niveles de protección sean equivalentes a los exigidos por dichas regulaciones, aun cuando la normativa local establezca lineamientos particulares.
            </p>
          </div>

          <div id="advertising-and-marketing-compliance" class="policy-section-block">
            <h2 class="section-block-title">Consideraciones para Publicidad y Marketing</h2>
            <p class="section-box-paragraph">
              Reconociendo la relevancia de la publicidad responsable y la optimización de la experiencia del usuario, Andes Game Studio C.A. integra cookies de marketing que permiten la gestión inteligente de campañas publicitarias. Estas cookies se utilizan para mostrar contenido y anuncios basados en los intereses demostrados por el usuario durante su navegación. Se garantiza que estos procesos se realicen respetando los parámetros de privacidad, sin comprometer la seguridad ni compartir información con terceros sin el consentimiento explícito.
            </p>
            <p class="section-wrap-paragraph">
              Asimismo, las prácticas publicitarias de Andes Game Studio C.A. se diseñan de acuerdo con las pautas publicitarias de Google Ads, asegurando que la implementación de cookies respeta tanto las normativas legales como las recomendaciones de mejores prácticas digitales. Esto incluye la correcta clasificación de cookies, la obtención del consentimiento informado y la posibilidad de exención del uso de cookies en función de las preferencias del usuario.
            </p>
          </div>

          <div id="final-remarks" class="policy-section-wrap">
            <h2 class="section-wrap-title">Observaciones Finales y Actualización de la Política</h2>
            <p class="section-box-paragraph">
              Andes Game Studio C.A. se reserva el derecho a modificar la presente política de uso de cookies en función de cambios legislativos, mejoras en el servicio o actualizaciones tecnológicas. En caso de producirse modificaciones sustanciales, se informará a los usuarios mediante los medios disponibles en la plataforma, siendo la versión publicada en este sitio la que rija en cada momento.
            </p>
            <p class="section-box-paragraph">
              La fecha de la última actualización se refleja en el macro 2025-07-10, lo que permite conocer cuándo se implementaron los cambios más recientes. Invitamos a nuestros usuarios a revisar esta política de forma regular para estar informados sobre cómo se gestionan las cookies y la privacidad de sus datos.
            </p>
            <p class="section-block-paragraph">
              En Andes Game Studio C.A., estamos comprometidos con la transparencia y la protección de los derechos de privacidad, ofreciendo a cada usuario la información necesaria para una toma de decisiones informada respecto al uso de cookies. Cualquier duda o solicitud adicional relacionada con la gestión de cookies o el tratamiento de datos personales deberá ser atendida conforme a los procedimientos internos, garantizando respuestas claras y oportunas.
            </p>
          </div>

          <div id="conclusion" class="policy-section-wrap">
            <h2 class="section-box-title">Conclusión</h2>
            <p class="section-box-paragraph">
              En resumen, la política de uso de cookies de Andes Game Studio C.A. ha sido diseñada para ofrecer una experiencia de usuario transparente, segura y personalizada. Entendemos la importancia de la privacidad y la protección de datos personales, por lo que hemos implementado todas las medidas técnicas y organizativas necesarias para garantizar un manejo responsable de la información recopilada mediante cookies. Al acceder y utilizar nuestros servicios, el usuario confirma haber leído y aceptado todos los términos aquí expuestos. La mejora continua en los procesos de gestión y seguridad de datos es una prioridad constante, y invitamos a nuestros usuarios a mantenerse actualizados revisando periódicamente este documento.
            </p>
            <p class="section-container-paragraph">
              Agradecemos la confianza depositada en Andes Game Studio C.A. y reiteramos nuestro compromiso con la protección de la privacidad y la transparencia en el empleo de tecnologías de rastreo y personalización. Esperamos que esta política contribuya a generar claridad sobre el uso de cookies, y que permita a cada usuario ejercer sus derechos de forma fácil y segura, manteniéndose informado acerca de cómo se gestiona su información en cada visita.
            </p>
          </div>
        </div>
      </div>

    </div>
  </main>

  <!-- Footer Section -->
  <footer class="footer-section bg-dark-blue-gray text-white py-5" id='contact-form'>
    <div class="container text-center">
      <a class="footer-logo-link" href="./">
        <img src="frontend/pictures/logo.svg" alt="Andes Game Studio Logo" class="mb-3" style="height: 50px;">
        <span class="fw-bold text-steel-white">Andes Game Studio</span>
      </a>
      <p class="mb-3 text-white-50">Andes Game Studio C.A. – Desarrollo de videojuegos móviles (iOS & Android)</p>
      <p class="mb-2 text-white-50"><i class="bi bi-geo-alt-fill me-2 text-primary-custom"></i>Dirección: Calle la Guairita, Edif. Los Roques, Piso 4, Chuao, Caracas, Venezuela</p>
      <p class="mb-2 text-white-50"><i class="bi bi-phone-fill me-2 text-primary-custom"></i>Teléfono: <a href="tel:+58 (212) 993-2140" class="text-white-50 text-decoration-none">+58 (212) 993-2140
        </a> | <a href="tel:+58 (424) 212-8326" class="text-white-50 text-decoration-none">+58 (424) 212-8326</a></p>
      <p class="mb-3 text-white-50"><i class="bi bi-envelope-fill me-2 text-primary-custom"></i>Email: <a href="mailto:studio_c.a._order@protonmail.com" class="text-white-50 text-decoration-none">studio_c.a._order@protonmail.com</a></p>

      <div class="social-icons mb-4">
        <a href="https://www.facebook.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-facebook fs-4"></i>
        </a>
        <a href="https://x.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-twitter-x fs-4"></i>
        </a>
        <a href="https://www.linkedin.com" target="_blank" class="text-white mx-2">
          <i class="bi bi-linkedin fs-4"></i>
        </a>

      </div>

      <ul class="list-inline footer-links mb-4">
        <li class="list-inline-item"><a href="privacy-info.php" class="text-white-50 text-decoration-none">Política de Privacidad</a></li>
        <li class="list-inline-item"><a href="terms-of-service.php" class="text-white-50 text-decoration-none">Términos y Condiciones</a></li>
        <li class="list-inline-item"><a href="liability-disclaimer.php" class="text-white-50 text-decoration-none">Descargo de Responsabilidad</a></li>
        <li class="list-inline-item"><a href="cookie-preferences.php" class="text-white-50 text-decoration-none">Política de Cookies</a></li>
      </ul>

      <p class="mb-0 text-white-50">&copy; 2025 Andes Game Studio C.A. Todos los derechos reservados.</p>
    </div>
  </footer>

  <!-- Cookie Consent Modal -->
  <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content bg-white border-0 shadow-lg">
        <div class="modal-header border-0 pb-0">
          <h5 class="modal-title fw-bold text-steel-blue" id="cookieConsentModalLabel">Configuración de Cookies</h5>
        </div>
        <div class="modal-body p-4">
          <p class="text-secondary">Utilizamos cookies para mejorar tu experiencia de navegación, personalizar contenido y analizar nuestro tráfico. Al hacer clic en "Aceptar todo", aceptas el uso de todas las cookies. Puedes personalizar tus preferencias a continuación.</p>
          <p class="text-secondary small">Consulta nuestra <a href="cookie-preferences.php" class="text-primary-custom fw-bold">Política de Cookies</a> para más información.</p>

          <div id="cookieCategories" class="mt-3">
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="mandatoryCookies" checked disabled>
              <label class="form-check-label text-steel-blue fw-bold" for="mandatoryCookies">
                Obligatorias <span class="text-secondary">(Siempre activas)</span>
              </label>
              <p class="text-secondary small ms-4">Necesarias para el funcionamiento básico del sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="analyticsCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="analyticsCookies">
                Analíticas
              </label>
              <p class="text-secondary small ms-4">Nos ayudan a entender cómo los visitantes interactúan con el sitio.</p>
            </div>
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="marketingCookies">
              <label class="form-check-label text-steel-blue fw-bold" for="marketingCookies">
                Marketing
              </label>
              <p class="text-secondary small ms-4">Utilizadas para mostrar anuncios relevantes basados en tus intereses.</p>
            </div>
          </div>

          <div class="d-flex justify-content-between mt-4">
            <button type="button" class="btn btn-outline-secondary" id="declineCookies">Rechazar</button>
            <button type="button" class="btn btn-primary-custom" id="acceptAllCookies">Aceptar Todo</button>
          </div>
          <div class="d-grid mt-3">
            <button type="button" class="btn btn-link text-primary-custom fw-bold" id="saveCookieSelection">Guardar Selección</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Popper.js (Required for Bootstrap JS) -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <!-- Bootstrap 5 JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
  <!-- Custom JavaScript -->
  <script src="frontend/script.js"></script>
</body>

</html>