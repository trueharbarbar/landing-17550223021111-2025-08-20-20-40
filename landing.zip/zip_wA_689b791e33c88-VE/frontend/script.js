// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {

    // --- Cookie Consent Modal Logic ---
    const cookieConsentModalElement = document.getElementById('cookieConsentModal');
    const cookieConsentModal = new bootstrap.Modal(cookieConsentModalElement);
    const acceptAllBtn = document.getElementById('acceptAllCookies');
    const declineBtn = document.getElementById('declineCookies');
    const saveSelectionBtn = document.getElementById('saveCookieSelection');
    const analyticsCheckbox = document.getElementById('analyticsCookies');
    const marketingCheckbox = document.getElementById('marketingCookies');

    // Function to show the cookie modal
    function showCookieModal() {
        // Ensure the modal is not already shown or consent given
        if (!localStorage.getItem('cookieConsent')) {
            cookieConsentModal.show();
        }
    }

    // Function to save cookie preferences
    function saveCookiePreferences(consentType) {
        localStorage.setItem('cookieConsent', consentType);

        if (consentType === 'accepted_all') {
            localStorage.setItem('cookies_analytics', 'true');
            localStorage.setItem('cookies_marketing', 'true');
        } else if (consentType === 'accepted_mandatory') {
            localStorage.setItem('cookies_analytics', 'false');
            localStorage.setItem('cookies_marketing', 'false');
        } else if (consentType === 'custom_selection') {
            localStorage.setItem('cookies_analytics', analyticsCheckbox && analyticsCheckbox.checked ? 'true' : 'false');
            localStorage.setItem('cookies_marketing', marketingCheckbox && marketingCheckbox.checked ? 'true' : 'false');
        }
        cookieConsentModal.hide(); // Hide the modal after saving
    }

    // Check for existing consent on page load
    const existingConsent = localStorage.getItem('cookieConsent');
    if (!existingConsent) {
        // If no consent, show modal after a short delay to ensure page renders
        setTimeout(showCookieModal, 1000);
    } else {
        // If consent exists, set checkbox states if modal is ever opened manually
        if (analyticsCheckbox && localStorage.getItem('cookies_analytics') === 'true') {
            analyticsCheckbox.checked = true;
        }
        if (marketingCheckbox && localStorage.getItem('cookies_marketing') === 'true') {
            marketingCheckbox.checked = true;
        }
    }

    // Event Listeners for Cookie Modal Buttons
    if (acceptAllBtn) {
        acceptAllBtn.addEventListener('click', function() {
            saveCookiePreferences('accepted_all');
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', function() {
            saveCookiePreferences('accepted_mandatory');
        });
    }

    if (saveSelectionBtn) {
        saveSelectionBtn.addEventListener('click', function() {
            saveCookiePreferences('custom_selection');
        });
    }

    // --- Contact Form Validation Logic ---
    const contactForm = document.getElementById('contactForm');

    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            if (!contactForm.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            contactForm.classList.add('was-validated');
        });

        // Optional: Add custom validation for email/phone if needed beyond browser's default
        const emailInput = document.getElementById('email');
        const phoneInput = document.getElementById('phone');

        if (emailInput) {
            emailInput.addEventListener('input', function() {
                if (emailInput.validity.typeMismatch) {
                    emailInput.setCustomValidity('Por favor, introduce un correo electrónico válido (ej. tu.correo@ejemplo.com).');
                } else {
                    emailInput.setCustomValidity('');
                }
            });
        }

        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                // Basic phone number validation (can be more complex with regex for specific formats)
                // This example just checks if it's not empty and contains only digits and common symbols
                const phonePattern = /^[\d\s\-\(\)\+]+$/;
                if (phoneInput.value && !phonePattern.test(phoneInput.value)) {
                    phoneInput.setCustomValidity('Por favor, introduce un número de teléfono válido (solo números, espacios, guiones, paréntesis, +).');
                } else {
                    phoneInput.setCustomValidity('');
                }
            });
        }
    }

    // --- Smooth Scrolling for Navigation Links ---
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - (document.querySelector('.navbar') ? document.querySelector('.navbar').offsetHeight : 0), // Adjust for fixed header
                    behavior: 'smooth'
                });
            }
        });
    });
});